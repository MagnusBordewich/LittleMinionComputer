#! /Library/Frameworks/Python.framework/Versions/3.8/bin/python3

import array
import os
import platform
import random
import sys
import threading
import time
import tkinter as tk
import tkinter.font
import tkinter.messagebox
import webbrowser
from functools import partial
from tkinter import filedialog

# define image data
DU_logo = "R0lGODdh1ABwAOYAAAAAACsEOi4IPAoKCjEKPjMNQDYRQxISEjgSRTsVSD0ZShoaGkEdTUIeUEQgT0UiUSQkJEklVUooVisrK00rWVEuXVIxXTQ0NFU0YFg2ZFo6ZTw8PF0+aF9AakJCQmFDbGVGcGZJcUtLS2lLdGtQdm5ReFRUVHFUe3RXgXRZfVpaWnZcgXhegmJiYnxihX5liIBmiWtra4RsjIdwjYhwj4ZxkIpzknR0dI93mI15lHt7e5F7l5F7mZWBnYKCgpiDn5qGop2JpIuLi6CNpqGNqJKSkqWTq6iXrKmXsKmZrpqamq2cs6+gtbGitqSkpLSkubWou6qqqrmrvruuwMCvw7yxv72xwrOzs8G0xcO2yLu7u8a7ysi8zMvBzs3D0cTExNDF0s/I1NLK1cvLy9XM2djP2trT3NTU1Nvb2+Pb4+Ph6ePj4+no8vHs8e7u7vLy8vj2+f///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAkAAHIAIf8LSUNDUkdCRzEwMTL/AAAHqGFwcGwCIAAAbW50clJHQiBYWVogB9kAAgAZAAsAGgALYWNzcEFQUEwAAAAAYXBwbAAAAAAAAAAAAAAAAAAAAAAAAPbWAAEAAAAA0y1hcHBsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALZGVzYwAAAQgAAABvZHNjbQAAAXgAAAVsY3BydAAABuQAAAA4d3RwdAAABxwAAAAUclhZWgAABzAAAAAUZ1hZWgAAB0QAAAAUYlhZWgAAB1gAAAAUclRSQwAAB2wAAAAOY2hhZAAAB3wAAAAsYlRSQwAAB2wAAAAOZ1RS/0MAAAdsAAAADmRlc2MAAAAAAAAAFEdlbmVyaWMgUkdCIFByb2ZpbGUAAAAAAAAAAAAAABRHZW5lcmljIFJHQiBQcm9maWxlAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABtbHVjAAAAAAAAAB4AAAAMc2tTSwAAACgAAAF4aHJIUgAAACgAAAGgY2FFUwAAACQAAAHIcHRCUgAAACYAAAHsdWtVQQAAACoAAAISZnJGVQAAACgAAAI8emhUVwAAABYAAAJkaXRJVAAAACgAAAJ6bmJOTwAAACYAAAKia29LUgAAABYAAP8CyGNzQ1oAAAAiAAAC3mhlSUwAAAAeAAADAGRlREUAAAAsAAADHmh1SFUAAAAoAAADSnN2U0UAAAAmAAAConpoQ04AAAAWAAADcmphSlAAAAAaAAADiHJvUk8AAAAkAAADomVsR1IAAAAiAAADxnB0UE8AAAAmAAAD6G5sTkwAAAAoAAAEDmVzRVMAAAAmAAAD6HRoVEgAAAAkAAAENnRyVFIAAAAiAAAEWmZpRkkAAAAoAAAEfHBsUEwAAAAsAAAEpHJ1UlUAAAAiAAAE0GFyRUcAAAAmAAAE8mVuVVMAAAAmAAAFGGRhREsAAAAuAAAFPgBWAWEAZQBvAGIAZQD/YwBuAP0AIABSAEcAQgAgAHAAcgBvAGYAaQBsAEcAZQBuAGUAcgBpAQ0AawBpACAAUgBHAEIAIABwAHIAbwBmAGkAbABQAGUAcgBmAGkAbAAgAFIARwBCACAAZwBlAG4A6AByAGkAYwBQAGUAcgBmAGkAbAAgAFIARwBCACAARwBlAG4A6QByAGkAYwBvBBcEMAQzBDAEOwRMBD0EOAQ5ACAEPwRABD4ERAQwBDkEOwAgAFIARwBCAFAAcgBvAGYAaQBsACAAZwDpAG4A6QByAGkAcQB1AGUAIABSAFYAQpAadSgAIABSAEcAQgAggnJfaWPPj/AAUAByAG8AZgBp/wBsAG8AIABSAEcAQgAgAGcAZQBuAGUAcgBpAGMAbwBHAGUAbgBlAHIAaQBzAGsAIABSAEcAQgAtAHAAcgBvAGYAaQBsx3y8GAAgAFIARwBCACDVBLhc0wzHfABPAGIAZQBjAG4A/QAgAFIARwBCACAAcAByAG8AZgBpAGwF5AXoBdUF5AXZBdwAIABSAEcAQgAgBdsF3AXcBdkAQQBsAGwAZwBlAG0AZQBpAG4AZQBzACAAUgBHAEIALQBQAHIAbwBmAGkAbADBAGwAdABhAGwA4QBuAG8AcwAgAFIARwBCACAAcAByAG8AZgBpAGxmbpAaACAAUgBHAEIAIGPPj//wZYdO9k4AgiwAIABSAEcAQgAgMNcw7TDVMKEwpDDrAFAAcgBvAGYAaQBsACAAUgBHAEIAIABnAGUAbgBlAHIAaQBjA5MDtQO9A7kDugPMACADwAPBA78DxgOvA7sAIABSAEcAQgBQAGUAcgBmAGkAbAAgAFIARwBCACAAZwBlAG4A6QByAGkAYwBvAEEAbABnAGUAbQBlAGUAbgAgAFIARwBCAC0AcAByAG8AZgBpAGUAbA5CDhsOIw5EDh8OJQ5MACAAUgBHAEIAIA4XDjEOSA4nDkQOGwBHAGUAbgBlAGwAIABSAEcAQgAgAFAAcgBvAGYAaQBsAGkAWQBsAGX/AGkAbgBlAG4AIABSAEcAQgAtAHAAcgBvAGYAaQBpAGwAaQBVAG4AaQB3AGUAcgBzAGEAbABuAHkAIABwAHIAbwBmAGkAbAAgAFIARwBCBB4EMQRJBDgEOQAgBD8EQAQ+BEQEOAQ7BEwAIABSAEcAQgZFBkQGQQAgBioGOQYxBkoGQQAgAFIARwBCACAGJwZEBjkGJwZFAEcAZQBuAGUAcgBpAGMAIABSAEcAQgAgAFAAcgBvAGYAaQBsAGUARwBlAG4AZQByAGUAbAAgAFIARwBCAC0AYgBlAHMAawByAGkAdgBlAGwAcwBldGV4dAAAAABDb3B5cmlnaHQgMjAwrzcgQXBwbGUgSW5jLiwgYWxsIHJpZ2h0cyByZXNlcnZlZC4AWFlaIAAAAAAAAPNSAAEAAAABFs9YWVogAAAAAAAAdE0AAD3uAAAD0FhZWiAAAAAAAABadQAArHMAABc0WFlaIAAAAAAAACgaAAAVnwAAuDZjdXJ2AAAAAAAAAAEBzQAAc2YzMgAAAAAAAQxCAAAF3v//8yYAAAeSAAD9kf//+6L///2jAAAD3AAAwGwALAAAAADUAHAAAAf/gHKCg4SFhoeIiYqLjI2Oj5CRkpOUlZaXmJmam5ydnp+goaKjpKWmp6ipqqusra6vsLGys7S1tre4ubq7vL2+v8DBwsPExcbHyMnKy8zNzs/Q0dLT1NXW19jZ2tvGVkw2JxkRBggERoVWBQgGDBUjMEZS3NZiTz8uIBgPCggFBAUA1ZWzUcgIAQTrDBjwV8BAAgYUOqTgscTLvGQ8PkRAEEDAP4XrEJKjoIEcARaFeBxEyLKlQoAECBh48MGGmIvCtjAQAPBBiXEt1xVQMIIMmQQLQxRysTKoU5f+EjTBCcxCQwMUgMBh0XQdgxcMNJh5IwGghkIjBD5dy5IdVV9Y/wC+e8DDzQ+1Xpcs4eLGS4YQBSgU4oCX7VoCS97yMoi1yRQ3akbIYEBunQIKNty8sYDjBYEHhSxUNsyWAEHFumTI1FDiiZseGHggRVgAwxMiWd5oOEFZQSGgpNkWOIFaV9oCJXrI8ALlA4bRCBIgCLFETY8TD8jdHMQguOECZ4vjer4ugBQybUoQ7qfOAIchXN5swUCbCyHp3tcakCAeV/aZRDRR3QdIEfACUwXIEAQGXnRQWQFWEJKfYQz0dws/0Y0QwQlGCGAAATAIwtSHGkyRFkIETCXIFtBN2BYCFtbiRUjlUPBEDx+eJohnBfBgA2UoniPIFIW5SNsWMc4SV/9LCmjgz2klyCAIDDI1xBIBQQwCRVdG0iZPkrE00dVCBfQgSAgECCClHKpBR8APg4jZZVAFJAYmLDwUVgAQZx4UQQJrqtYSAWYKYtCcgxJxJywoqKXQEIJoEAADLqQhQwCByoSijociiiKfi7oCQmUKCakBAyU8cIIbT3iUqUlrygEEl10SGqorFZBDThKCYPDZE0aY4YYNIDygpiA2HERArD3QaiQBOdzaSq7kPCGHGVaxowERblgRQRDZgYhsTC4M0qynKNYgLSsVFJAAFHKIUVY/HSzBgxdbaMBBZQSUK4cNAaxgrrMumrbuKhQogIUcYUSAVwA2cMHGCiei6K//DMQJci66BNBwsCofLLzFA4XBIMUScLgA5JX+IqkxwRMa/DEqbcihU2EGnPCBBk9YGVS/hWzsqa0zoyKFAkWWk0AQSyjQIoopEMJDAJ4qFECWRZtihkbd+RPTPw19gLRCILX1gX0rjkAq2S8F9HVMACXQAEkRZp0KGFgsEUQOL6QwwgcWWECBBA8UrsDhh5NhyD4MFB4BBRRgoEEHIZTAggw8BIHEFC7b7fktVwhhAgQtfE6NExAAoLrqJpjOSBELxA7B7LMfsADtsl/QghK1KHHA6iq4zsgXTpiwuuoXfEEI8S0soPoGvMuiA/DOdFGFET/Y4EIJO2NggQQRPMBA/wMMlM9AGYZIYH75D0QgQeAafDACCzPwEE/niRi/evSHKOE8ABeQRRSolwwrYCAC/PAa3ADCtgYuZARfkkMXTuDABrrtaw1RwAMsAKlDOOF4UVjEBVbnA1gMUHXBSwYXrPQ07wQgY3KYWtUCICRDaAGEjPgfAEroihMCIIXJoEAL81MAlLwMXQlIxA1X5wRGfHB1IWyFD4GIDKZ4qogDuyIHlHi8JjJiAquDQA8JWMCkEdGIchBarUB1iCWqzouL8MHxhCBFMiYjV4gqgMCOiCjfcJGJjfjC8SZQRxQyQ40Fe0EW5zQcRbgRAHBchA4BAIooKmKKhXCCEpyghUZoQf8JPtCBDyKZiCi0jhCh00EROnmIKAhBCPxLxMqeFatZ5XFhf3yjI0a4uiLIYXQHmN0CDnCFQmgBArKLnQcIoQQdmOACAwBADAahgt8B4ADTlAMm5eADCERzdQu4QSKatwATxCAGIohmOA1xhSKoIHWQFMQNFvBN1UEgkiY4QD0BWExECKpW6jIUzL7zgUU8kpSJEMHxsimH6UHxEFfgJQAJIQIwrm4D2lyACITQgtXpQJvU28AFvPiFjj7PEGNwHiEL4QHkFWID8FQdHSfggShGtJcZbYHy5IA61Q2gn4fAz7N4MIgkDFQ4UzBoFx2hguOJgBAtVZ0lCyFIlxbChxP/0MICLGnSp/pQBBsoXSFi4FGWytQQZ/gmQwdBVtW14AJrFQQ8F+CEA0xVDmlV3UoPQaVaFUoOcjJSAQqqVEA2wqSqW+YgEHvXQeR1oobYgOpsF0s5bGACxfQhABRriG+KkRAWbawceLnXQYxhdQPAqCHk6FNxGqKpqmPlIWaZHywNQgpmNIwB6ubIpR7WqYRoKwBEK4hvBtAQiC2tITS7U0NYlJKEcMIFqAhV1S3gEPUU7RVQiwghrI6OiFDJs2q4pILBsLcP/e3qnsrW9GLXqmNdnWsRgdVESFZ1kFAoAK7bWZ8iwo3HNYQSypoIq7ioACqyWZcUYAZP+pYR+jNk/3ulmgjjHkK4vizl6k55iKhCtxFo+N8B3guAz7JzvYgYsOo+mggo5PYpBUjqIJ7118LqshEeBgCLBSFc4srBwoYQbmWvakez4nd4MXjuiPtb4v+iuH8ETsQKjtqSAuAPQ94BzyMe6eNCPHe4wXUvkwMcZtUNmRDb7PDqFiGEC0AgBmOw6JIL4Vknq469Ao5yIiQwxKCQIwyEcECfg5KALmz5wYuwJgAGEF8KIwLIjQbAmQeRZkN4eJwDGAAP5WBR/tLZnojY7p1TrGdESGHQLUkiIfjsnTdB4qAOfvKEwfxo+JZZ0pcscnWPPNZo4lkQnSaxiY0p60KoWMeNSFZw3P9CCPKQhgAkiASsGXGD4wGVx2ImxGPJPOtJC6LSRv6wIMYAz7hy2rrCtjMAfs3MUicCTaSZyWBe3A/BSBuHjIgpZ2dN3NPautu5lrCaeS2I/6nWy+hm8rAJ4UZ2D+LYO2YEBV5sgAqgheIKMPS998eIYw9gDEHO9iBEDdlIexukArf0mhfLcecm/NNNbmOx273iR4CBtnQKzyBSkFuFWEsSj4w4InR45mqbGRHC5Ta2j67hlIcb5MBenWwJMdd0y3zUUK75I6hAI6cUQCmE+KdTFtJBSZB8s4vwcIbzrLr5EgINilbu0nHd9B8mwsNQl0NMEepGTxPim3IfxMwHUQT/dy/iCV2vctQIgUiWlKkSDl3dtQkxhvtCYPIwX7ggNqACER8CsWv34IYTIdG86xfthYgpow0RxlCvbt+EYK00JbGE2fwsVgKFcY0jUdfjLRq8I4ftAoR+4fWeYeQTaJ0O3S6HL+hQ6bu+5tQH8US3DuKRLQD5F3RwAGeW9QbRizwAQj+I0/8Urc9dQN4fcbTCEO22OCsA1ng/gUn6fr+1GwAEVIDQRAgXABOwAbHDQ6mTaQAoTjowAZl2AAx4TRcQS1FwAb/DgPo0ABPAUCaggAPAgOqUPDwVU2HkRSA4AV8gAqlDgdEEAXh2Ac6DghaYTW2mTxS4aDQVCVwwL1dy/wSFsEJVpgB2ggscJQIisDu34AQ3cE4+MH1CEAM30H//VQmY1wgf0BQFAC+FYHsEQAFoIzzEYAMLsQ5bOAgNIBSLx4XdYAEHcQgUIAAPUENmeAw7YG+F8AH+8oZ2eId3sgEDAHyxoAQWWDQqIFIbIFIeQF1ycAMeMAE0JVaQ8G+voD9RGCrkZl3r91ILgAaTEAMX0GWrMF12Y3SMeAjuhIfDwFrEx0zmRoq84F3IlgjNRA1DeCuseIoPx3zOIEe2GCOzqAhKMF9acAMrFQUtMIipqAQqoFg6IARFUASvNAg+oIw+YElOoAIqYAL8h0o+4AEwqAIxIFs3YALgWASbJv8HV6ADFyBbJnUBN9CE3LSMQrBjzFgEtGgNu+iKrhUD/3MF53QFWtBUAzBV+vVZUWBRv3YFYLRpMNVPA8ZeShBVyeMBN2BScpVCX9BSOzVPqgNUQvA7G/BKIWRSdkUIksWH2lCPKeaL9hR6LaVckrVXeSV0KjBfYLR+ZAVEHXUAHnB8ctB5OylueidbS3RtqcN8qcNtPsBh3GCS/eN20XRwgiBHqzcIxlNaCqVcAdZRSIly1Kc64yhXAMCHkVRVQjl7sac6zfVL01eSWneSf9eKg8CKhTCVqJSRlAZEKQiO4KgCvNRPJ5SWUaUCZzkIYkl1ZNmWDHUGsLcNSilgTPn/lYUAl4Qgl4QwQnimAgq5YleQmZqpBbJ1QoFJjsdjAoE5mIOQOubWVJ52A+S3DayVi7XYll3pXVEpCJJJeKoDdXhmdJFIaWbZRhJVmM1Hl6UJnIJQVdGTmNugYqFoCEIwjtFEkrIZlwBoCM4zTc0oT47WdJ/5cBK1aaTplakoWcukBKm4DYmlCEQ4CNEUm4smnXJHVgeABkipYvP4bb2pCE6gUoIpnOCZdWOQlRcxQrNpCNy2no/ZnpE5nay3WcwXTYGHZvdJCEI3QJ72nXpHnIPgPJyHGkvkcILQAg3qmIRQeAOAidSkoIWgX4FpdF0pB8B3QpWod6zHWf52bWBktYjYSWuK0XsecJYlmJVPlJWwBUdrAEYfd2JOKZWqw1ADCXxttZrrFmZAVXgA4HbV9ln6WAgoWhwt8DsQMIgTcAEkGQMeUKacV0z9uAEeMIilY0pqqqYkyWlxKghC0GkQsInUpKZrSl0tMIwx4AMVZUkxoKcbKpX6J4SW1qLFEQWMKkCcWEpOOAlJqorKYIyU6gwbkJaXagxOMKmbagwT8Kif2gtacAHQN6rCEFuoegxooGmnEAgAOw=="
ECS_logo = "R0lGODlhQAG7APcAAAAAAP8A/w4JChEMDhMOEBYRExkUFl0VZBsWGB0YGl4YZmAZZiEcHmIdaSMeICUhI2UibCkkJmglbismKGkncC0pKmwqcjAsLjMuMHAvdTUxM3Exdjg0NXM1eTo2OD05O3U5e0E9Pnk9fkI+QHo/gEVCQ31DgkhERYBFhEpGSIFJhk1KS1BMToRNiVJOUIZQi1VSU1hUVohUjVpWWIxXkIxYj11aW41bkWBcXWJeYJBflJFhlWViY2hlZpRlmGlmaJZpm21qa5lsnXBtbnFucJpvoHRxc51yoXh1dqB1pHl2eHx6e6N6poB9fqV9qYF+gKh/q6aAqoOBgqqErYmGhomGiKyHsK6JsYyKi7CNs5COjpGOkLKRtZSSk7aUuZiVlpiWmLiXu7aYu5yam7qbvKCenqCeoL2fwL2gv6Sjo7+jwcGlw6impqimqMOpxauqqrCtrcatyLCusMawybSzs8qzzLi1tbm2uc230M+4z8650by8vNC80sK9wsG+vv+/v9TB1cPDw9XE2cnFxcnGydnG2dbI2svLy9DL0NvL3NvM4NLNzdvOzuHO4dzR4dTT09vT29rU1OLU4uDW1t/Z5uTa5dzc3Obc6uLd3erd6uvd3enh4enh8OTj5Ozj7OTk7fHk8eXl8erq8evr6/Lr8vTu7vLy8vf0+Pj1+Pr6+gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAkAAKoAIf8LSUNDUkdCRzEwMTL/AAAHqGFwcGwCIAAAbW50clJHQiBYWVogB9kAAgAZAAsAGgALYWNzcEFQUEwAAAAAYXBwbAAAAAAAAAAAAAAAAAAAAAAAAPbWAAEAAAAA0y1hcHBsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALZGVzYwAAAQgAAABvZHNjbQAAAXgAAAVsY3BydAAABuQAAAA4d3RwdAAABxwAAAAUclhZWgAABzAAAAAUZ1hZWgAAB0QAAAAUYlhZWgAAB1gAAAAUclRSQwAAB2wAAAAOY2hhZAAAB3wAAAAsYlRSQwAAB2wAAAAOZ1RS/0MAAAdsAAAADmRlc2MAAAAAAAAAFEdlbmVyaWMgUkdCIFByb2ZpbGUAAAAAAAAAAAAAABRHZW5lcmljIFJHQiBQcm9maWxlAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABtbHVjAAAAAAAAAB4AAAAMc2tTSwAAACgAAAF4aHJIUgAAACgAAAGgY2FFUwAAACQAAAHIcHRCUgAAACYAAAHsdWtVQQAAACoAAAISZnJGVQAAACgAAAI8emhUVwAAABYAAAJkaXRJVAAAACgAAAJ6bmJOTwAAACYAAAKia29LUgAAABYAAP8CyGNzQ1oAAAAiAAAC3mhlSUwAAAAeAAADAGRlREUAAAAsAAADHmh1SFUAAAAoAAADSnN2U0UAAAAmAAAConpoQ04AAAAWAAADcmphSlAAAAAaAAADiHJvUk8AAAAkAAADomVsR1IAAAAiAAADxnB0UE8AAAAmAAAD6G5sTkwAAAAoAAAEDmVzRVMAAAAmAAAD6HRoVEgAAAAkAAAENnRyVFIAAAAiAAAEWmZpRkkAAAAoAAAEfHBsUEwAAAAsAAAEpHJ1UlUAAAAiAAAE0GFyRUcAAAAmAAAE8mVuVVMAAAAmAAAFGGRhREsAAAAuAAAFPgBWAWEAZQBvAGIAZQD/YwBuAP0AIABSAEcAQgAgAHAAcgBvAGYAaQBsAEcAZQBuAGUAcgBpAQ0AawBpACAAUgBHAEIAIABwAHIAbwBmAGkAbABQAGUAcgBmAGkAbAAgAFIARwBCACAAZwBlAG4A6AByAGkAYwBQAGUAcgBmAGkAbAAgAFIARwBCACAARwBlAG4A6QByAGkAYwBvBBcEMAQzBDAEOwRMBD0EOAQ5ACAEPwRABD4ERAQwBDkEOwAgAFIARwBCAFAAcgBvAGYAaQBsACAAZwDpAG4A6QByAGkAcQB1AGUAIABSAFYAQpAadSgAIABSAEcAQgAggnJfaWPPj/AAUAByAG8AZgBp/wBsAG8AIABSAEcAQgAgAGcAZQBuAGUAcgBpAGMAbwBHAGUAbgBlAHIAaQBzAGsAIABSAEcAQgAtAHAAcgBvAGYAaQBsx3y8GAAgAFIARwBCACDVBLhc0wzHfABPAGIAZQBjAG4A/QAgAFIARwBCACAAcAByAG8AZgBpAGwF5AXoBdUF5AXZBdwAIABSAEcAQgAgBdsF3AXcBdkAQQBsAGwAZwBlAG0AZQBpAG4AZQBzACAAUgBHAEIALQBQAHIAbwBmAGkAbADBAGwAdABhAGwA4QBuAG8AcwAgAFIARwBCACAAcAByAG8AZgBpAGxmbpAaACAAUgBHAEIAIGPPj//wZYdO9k4AgiwAIABSAEcAQgAgMNcw7TDVMKEwpDDrAFAAcgBvAGYAaQBsACAAUgBHAEIAIABnAGUAbgBlAHIAaQBjA5MDtQO9A7kDugPMACADwAPBA78DxgOvA7sAIABSAEcAQgBQAGUAcgBmAGkAbAAgAFIARwBCACAAZwBlAG4A6QByAGkAYwBvAEEAbABnAGUAbQBlAGUAbgAgAFIARwBCAC0AcAByAG8AZgBpAGUAbA5CDhsOIw5EDh8OJQ5MACAAUgBHAEIAIA4XDjEOSA4nDkQOGwBHAGUAbgBlAGwAIABSAEcAQgAgAFAAcgBvAGYAaQBsAGkAWQBsAGX/AGkAbgBlAG4AIABSAEcAQgAtAHAAcgBvAGYAaQBpAGwAaQBVAG4AaQB3AGUAcgBzAGEAbABuAHkAIABwAHIAbwBmAGkAbAAgAFIARwBCBB4EMQRJBDgEOQAgBD8EQAQ+BEQEOAQ7BEwAIABSAEcAQgZFBkQGQQAgBioGOQYxBkoGQQAgAFIARwBCACAGJwZEBjkGJwZFAEcAZQBuAGUAcgBpAGMAIABSAEcAQgAgAFAAcgBvAGYAaQBsAGUARwBlAG4AZQByAGUAbAAgAFIARwBCAC0AYgBlAHMAawByAGkAdgBlAGwAcwBldGV4dAAAAABDb3B5cmlnaHQgMjAwrzcgQXBwbGUgSW5jLiwgYWxsIHJpZ2h0cyByZXNlcnZlZC4AWFlaIAAAAAAAAPNSAAEAAAABFs9YWVogAAAAAAAAdE0AAD3uAAAD0FhZWiAAAAAAAABadQAArHMAABc0WFlaIAAAAAAAACgaAAAVnwAAuDZjdXJ2AAAAAAAAAAEBzQAAc2YzMgAAAAAAAQxCAAAF3v//8yYAAAeSAAD9kf//+6L///2jAAAD3AAAwGwALAAAAABAAbsAAAj/AFUJHEiwoMGDCBMqXMiwocOHECNKnEixosWLGDNq3Mixo8ePIEOKHEmypMmTKFOqXMmypcuXMGPKnEmzps2bOHPq3Mmzp8+fQIMKHUq0qNGjSJMqXcq0qdOnUKNKnUq1qtWrWLNq3cq1q9evYMOKHUu2rNmzaNOqXcu2rduKfNyQ4TLFyREgPnTwObjDh48jSaZkIeMGT6G3iHnW4ZLkhokOFiA0aLBAwYIDCyYfuGLQzYHJC0KHngxBwgYSMoRciZO4dcspNEBAsJy5AYTbuG+L6HB7QRKDXhbkHo4bdGYIHV442eu6ecgjlCdbUCGBuGQIG7J44mK7wQ6DToRb/x9fPLMQ5+g5kjkgWYKKOqRU2B7+WAWUVHwmN2hhEMh88gBCcMAU6RV4kQkNSHBDBy3EkYoQ7OXWgBpq3AAIfh2A0IAJBt3wX4DkbWDgiBNFJkEdc5GSyg4tRJabBV5cmIkKYQChQAcGyQciiCT26FB+t1lwhSSpXCFDHC7eJsEUSfCRihsbXIGgBQaJ8OGOxDXAmo9cIoSGcB3IlciKOsgwnARMOAEEH5W8kISSBm2AJYALZNHlnQVNIZwFLcjAhCNu+CDDlQpAkAiRRxRRHQQGJTkncQscgeekqvinpAykeGLKDgguwMQaECzwAhl8qJHKFLxJxtxAiz6a5Q2U4v85qGRMAFJrHbz5JpAbDYBwhQo+1EGaZHUU5Op4DagQ650I3raBCBBkMQVmThDkhoAdOJGInL2tQRAgVx4rmQjLdtnBfwocwccRB1Rb0Bq9rmFCbguQQZCw4hInYrk+OoqcCAMOlMR3u0r24QJeEBRHuOJSyW+Prd5GGWcCHRGaDwNdezDFAq0hXr64SfBwj1lyMZAQx0GAccfX9UbgQGR8DPJtI48IroQmC+QDezegeMDKqmjcGxMEiSEzyA0AUnOB+Epsr0A7QCCCCEKYUgkFPw8Eqm26DsTF0fk2oMfS6TXdwNOq6HBAC4Dc4IXVIICQNcuUnTdQFmCL20CxZDv/J6xtagxUg3g71JHKKTdMAd0CQIOqgN0C6TlzcVv27VodhXorkAzCNXDDYKhckm2zjGu9AOSqSD65ZG5Y3pywcwzUgngbCgGEF6TckESrpQt0BuqqT95A6667RrwqLVx5gBeepKLGDo72blDwM+9dPHrN5iYBGno4YQoT/oYKNEHUI8339a1lP5wKImygx7nWST9Q+WGviv5bIOQtGQVo1GHleAuAFUGiECGkUUYQ90PMEUCwAQlMhjb62Y8FGIYbSRXEChSwTnciSJnKkMYCHTCBABPYGkHMgQxWSIIPbvACE4CgA5CxgARmmBsQIOQFCZqhBSywgQyRwAQtuMEO/4TAhCsQZmwkTCJi9oCFQCjxiQkpgxR+cIIKMGAAY4BiVALxhj3sIRCH8KId5MCGMnShC1sYQxv2wBMkrCABCWCAAxCQRS0+RQofqIABGMBHBiTAABqwAQ94kAMYlKACDriADbqgkzc8QI50tKNUzBABOTogAR9AyB6MEAECPMAGfsDJG+dYR0lKxBB1WANdjrBCGagABSQQwQvj9kL+HGRBtITh1Eygghfc4C9OGEwdENgQKSDAAXMMwkJ4gIA4EuEmOEgAKU3pkCPIwAQbiEwHR8PBDeoHAmjL2AQ5aDAOimYyEsgAaoCQEDtIc45GYEgT4miAEtgkmtOkJkM2kP+yfB2gCAS5QgH1NpmEBIKP8GwID6SJyZrYQJqR1OdCfEDBOZ2OfPqb04YScgiEIiCeDbkAJGNAE3xGVKIJ8ZjwCBa5jGKpawchhEdBypAlHDOfMTFpKVGKkPC5yjsYFZ79CiJTSNJ0IYdwgBwTwIGZPBSnPOVLRXfUgPHR71ENIBdHZ/qQEbwTAWmQyVNPGlWDNC1swHMpiBTwMoR01KgP+cE7E2ADsUJ0pyqhA5f+h9aAqjVADtsqXB2ChZsyQAMDCcISqMBYKSzhIFIwghQai4Q3HCQQYwgCB6RAkDHwgAU2wAJBxlrKLsAAAw+owAdyEFaFBGIJJyhBCk7wgQv/hOAHljXoE0JgADkMZAwsmEACHoABGJjBIEsIQQQcMIEP9ICNY8EbyCJFkK9Nl50KeWtCHfKGd8pxIFLIAQMMgAADGMCJBQGDETxQAAQgYADKHMgbNPCABLjXAC4QSBouUAEO2NcAIxiIScugCjZo4ARL0MISRmAA+7IgIT2I4xcIYocVtDcFBhnDCCpg3/FqQSAjCAESFDyCZhqgrgKhwgViQAUtDKEC7k0AZ8eyganSiWgDCc7MGKLdjz5kD++8pF7lK0c5ovcgJ4DoUVVxiDckWakeUMUYNJDbNMixAIxUhUnTMGXfEkQJ0jTAgw2CA/LOuCAhYAACAlyQPXRB/6Rz5GwF8BqEMA9BFUYYwSEKkmQ1tzYsVvgrANuqipiFTQc85qpDDopMBxjgzwLBAEL3jBBjbtcgVjxsGqJMEBwQoACtxScDbMBpgzz50QZ5ZAKgW5AtHBPVBunCMRMQgw8Q2CAe4GMFmtBUgzA6AWwWS43FtQCOqUKl+WpIj5ecXUvOEQwF4cCkE4IFA1y6IDOQZgQqAGmBSCHLqnjqHLs9EC0cEwE8wHQBIoCQO0AUCZe1JK0RYoSbghUhaf7uWK4gaEjlTCBnfZT8ElLUazPE2QiANkFyLUdKH4QK1vbxQYYw61In5KkJsCdC6MBQDBtECXZACKMRcGeDJBWSuf81iKuVeoGExACiKQ8LXwUeTiAdiwIOKbjEG8JoZN574dNGCMQNPpB6XzLdCxnrYzcuTQaEICIjf6bJlcqABzwCIWOYdX4R8lRYi4VXx1qA5gZi4/hFIeeKbgiQG52AIQ+E4Q5wuEGGvvOCGB0BT2AIaRPCcaU+HSKWrvtATn7YhGT9kjm4eJjJ/RUP/fR8AjlWrx6ic2Yn5A2GfQCuEUoIakfc8ng+dxX0DtFbH6TvTn/IGE4LSakXhPC9PsjhE5B4ri/eLD4FUAOGmnvyaOkhy37IypUa+7dzPiFV+Dy9z00F0kO1IKj/u0L20INA7oENEHU9QWBv+FnX/iBjZfz/V6z7qEYJHHWJHmxDgnDTBOBg80b2PNEFcvfmJ730fG96sGVfAvdTGg7npn2DR3XFVxCz930GEX5nMStzYhDwQ1U2BBHB5xBPNm7wF3fyJ3hFJ3rOR1bQp39Y9wEE4AF3QBAAOH/ch3Xep3gWeBYThCWBNRAzByKQ1xCV5xCWUElKhVgXKHcFUW3zF3pzZH8KsXdMp1T7NxAxUF4wYBAniAACKBApKHsraHstaBZgtyP7QhA6AiILQGhop34L8QU3ZQBECHRy1HmVpnwHUX8MMWD5h4QGEQLNJH0mGIAHMYUZVoXgB1HiFxZRIGgRSBAMSCcjJIEeFV8M8WQNdRBw/6eGbXhuoOeGC6FTcZh6BMED1pYAjPeElqeHBsiHCeiHanEDarVRBbEDNpZVFKFddNUQadB0DsBqBfEBQXcQo6SB9Md8HYhXBBF9BVFJVXd1BtFdcxSFTEaA3Yd4LPhzaaE+GvQCBmExuheDUIdQwMYQjyBpfnRcCMECDEWL22dJuiiECHCGCGGJR4iJAsFow3gQhYWCyqiCzGiFzpgWGuJ7h9hSvicBQwURfUd1R4YQ/Tdcf2iOonUQM3AByJQAPbB8c5SQCmFS3ngQ7iSHgydvMTcQGgBJirh980iFR+dypMgWD5gl6KcKOqZBEFA5E0EEQZYAW3cQb8ABDbYCDP8BZHxUgAJBBDBQBk1nhwSRA0rGECkAURJpEGlwTAxQgB7AUDhJEJawAh15SVFZEO5YAZ1QaVqXEP0XkW4xbJBydgXhBnljG8cjEYfQBH3URxk3Bo/QCZ1gCYGgBSVQAAzAAgdJEEGwRxlXggKxByuAk3SwR2rWBAbxBZcERxFwkFIAR3CkAW5HEHvwAc0ER0pAEG/gR5cEA3JwCHSABBMQT1bkAA/QBXsAA7l1CDBwmQjwkMXIYXDEAB9mEI8JmRgwmWqRj8OhAP82EHkQLg1AATX4EEagAReQWhWwnBXwAJU0XBVwAdLpAYskEUswAQhQAAVQAR5wARhgf3cQARr/wAG15QFLBwMfgAEeEAIh8AEccAEfgGIEsQLp+QHs6Z4Y8AGKWAUfMJ7s2Z4XwAHBRgchYF/a2WAlkFtsEAHmVQAJcGeB4J4aYJ/tiQHkGXKqoAXIyQEhMAIj0J0e0IQCQVv5eZ/vqZ9tgQJHI3YGkQhZsgH/iBNvQAVLsARYoJs5AQZYoAVsIHtY4IvoowMyYz3mhxsLwCFlVS5T0DIQYAgHwS2TkZJJOil6IAKZYY0DQQKUYQHhNKXlwgQQgKUC0QIHwFJeOjKA8BsHsRpn2qY3wQNJeRNvgAM46qYmMQZvQAd2YAd08AYV2VllkAZtUAYKJxE2UAAGII41UQHb/2mnK5FZfvRHM1AGPqgKbyAF9bUEG/kQREAADrATIpiEjnoS7NeICdEEJGURaTCQOPGno4oSsoYA76cQabB0r9olWYduC5EGiNkVQHqrGpGrSJcQteoVEVCnwIoRwrqrtqoVJWAAoZSsHbGstNqse4AEGqcKSzADK9ADm6oKTHQCbSAQZ5QG5pqUXTAGadAFk5kGQTAEQcADeIVZPIBi1xoESfkGPBAEPzAEdBCncmAEJxBtccQDjgUHqpCu5npG8tUF6yqtDEGtCcEGtsoDD7BHqoAFQUAHdXmxH4lnegRqgdmXBvAAf0oHljl6A0Fb0boHF5CtafByBlABqiAFBv/7AQOAYseJXvPVcgNhA+M1AQUxBHxEBF2gBSFHBzZZACwwmUEAXxC7EBKLEBRLEF0wXDGQlLFoABsZi/e4AgjAgwTRA82qARFgCZpZAAMLXggwAT+QZYfwSapABwRQm+2YSXyJADRLEIEAR6zKcQigsgNBCHgbtd2nq9XKt360tgPRCXq0ZAd1j0vJAOJ4laoAAwRwZgOhR3/WtwlguQOxBATwsc1aszNbEO62anOIANkqEGOAjoYbiohLrM3qB+MVp6pwAQbwsZHbbTY5rOCqiKlrBGxgrgt7RbCpCgdlAJoLXnsEegLxBKdLEKmrqIVFuaMVuwoxtQdRrANhux7/mLu7i5V+VhBSYADsVnSAqQpEgAAPYARNEL/yKwVSkHLL+6uXpLelOxDSu7cDUb0HoUeK6Acfq72d5V7AexBtULtq5ou6y7vlG4zM+7PzmQD+61rj9atvoLtqVgH727+oC0eKqgp96bPsu74GHIrut6uaC74OPL6Ke48CoYm9VgZ2qwoFesEGNV6FehBLAGPjNWb8O70DAWSq62sNLBDymcIf+LkLgQXgpgoubBAPTL4yDK5JnMBvZHUMcb81ZUVmSBAgTJkijBArIGYJG8VMTBAiZcIIkQMDOcUFUcUxzHgpYAArEAhLVm9XjMQG0MMc9QEnJsZEHJhlLJJ7MKtr//xxDabGBLEIIvq9STzHMDwQvUuFEXAC4ui5QrzDf3wQCSxlBKDIqjDGBHHIB6EBmNSri2wQz1oBrDoQLLCRy0tudDwQgxDBBqHKrZtYDYa7R9VRBgCkKdBtZTAAUXy+WlkQc9SjCLEEGNvK37huapwGJeDIS6CdCdxdBlC43qbNz4xF6UheRoAIAmEHKdCsUqCdS7yyD0CLH5CEFibDKUAAMyAQbJCZBPEIDJCq0ix7K5BaI7ACJxACcGwQQYADg6TQuWUEObDQPJBlCQ3RCMGTnVUCfGShJQBpE12vPLCRUlAGLGCwSlACyTu3PKDQKb1kMPAAIRADJVcQK+DM///cFXQwwhcRyTVNIl3QvDtdIKD70+mRBqEs1M7Ry0btHEHQyUntGnugAQjQ1OmxBAPg01J91Vid1Vq91Vzd1V791WAd1mI91mRd1mZ91jARy2jNEVSARmukEE+wwhoRBAWQdxHRA00UBP6sCmagrm3wBlyGuxLBAKQsEhTnpoybBkKrEBdQ1BQBCTIWEV0Qe0l5CLo7ZIfAA/sbEVSAsCWxB1bNUzEAbwMR0wjR2BthCZENETGg0wURAwxggGsNER+w1wyB2hqh2qGdEClg2wQB27NdEZp40gXR1+CG2m/wo8Voror6Bm0AabpNrGlgegJRAkE9EDAQ264r26qQBt//ppSBKsUqSweldGuXugXL7YtmYAaQpq6qcAd1VJdFzEiD0AVNII50wGVO9AXUXTwV4EnE3QUpsGe7FWnXHAgRarkbLRBBoIhjMOBMVswCEd1KeQJ7dggrUEdjQJ5jQNO/zQBOJK8EUW3yiuAfwLhv4AF7hgUaMAY5sAV0EAEaNwYJAANfAEYrUHwZrgqQkAIK9wYlMAhz+3dj8AAbTQcz0IQ8MADQlQIMgAVv8AiuVpE28EyPUAI4MAbXbTk24ACeOmN0gACKOp6/VQAD8QHAGwGitQcI4NkFpt0UXhCcOBAcNxAr4NtKyAA06gCuSuaua+YC4QGup+Z2zrhVROcE/4DdVzlPAuEA6C0QHzBmdQaJqiAH0KpfBCCRHCCimEeMXZC+SmQEDFAAEwYDOiwQF/B9aXBelkoAMTcDGKAKPQDqAsEA8RTnpc0AaDsQDwCbKeDaBJHdAkEHaqwBw7rqvC6RGvB9K+BxqmDdllwAuYUAoYUFWKAE6WZMSmDtGrt0RqDDb3Dp3c3qIxqVWKB5AhHulXo/sTiwGiCquXvsBrBnVVAAtFhnqkCVBVEB+fUIq00QLODGqnBgAvHrLqfdB4EBPzAQq45eK4BilZAAEknQA1ECM+kH0i5lA0BuMYDuBkEE4C7uq+5wJxCVQIZeS/CpCaSbKYBYH2BxA4Hb4/++Z2NAAJOZA0ILAwIfAemG60pM66pQAfesCgaPEMCNEBigiA2/sl8wCENw0s1e8Ref8WmAzGSWAAgB8gUR7tG69OU+EF2Qx3CwAt9qOcR9Ak34AwhAjGws75TGAIKrChygTF1gAGwfCAagV5Hw7wNhBgXgcIeAAM68AsCe57EmEBqgiGxA7glbp1Ff3TMZCAXgZXmZYQMg2N++9SI/7wORAkLssGp9PQ9QSnRgwhMQya3lAEKMBQKQW12gAZHgutIHA8NqAyAl+QWsZfLJA8lLngmhAQNg1wIRAzP2AFepBa2vxEHwBnCgmx4QexPK8AKQZVtgAKQdCDM2AwyQW2X/MGTaz/YZKgDjmrHJH2mFewF46uYJVJdSMAZVsGRDYLBSwEZYUKOt1QRLcGZ00ATr2rxdABBY0kgZo8oglSVLDC5c+EUgwYVbEmJhuFBKwiVdxmhZgsMgxyVpDD5ZIsVgmgcFVCKwYRBMQjCqXi4pqOrik4V0YtggQnGhFhY8jIhUlWYiwyYlDSY0qapLwpoxDKgsMKFMRaxZtW7l2tXrV7BhxY4lW9bsWbQM5aTZQ+eNEQM+087d2kUVHTpjSkSg29fvX8CBBQ8uW6EiDh6E59oIUvGBYsiRJU+m7BcOh8N2K4tdoXkh5s2hRY8mLbhHU1VlEpf2yoKOwUM9iLKm/13b9u27Xb6MeY1b6xiNV30PJ17c+HHkyUOn0aLc657SgaA7p14dKw8CXalIScMGzJtAxB+UACwFy5gqaWZn/XDB+nvraQxspXMBderHw99M7wvjy0IcGtuqLfgKVG6M+bRKoAesjODPwK724IshIyC0ED4EtWIhgUGMW4GwNwx440ISRxOoC7lUkUiVN6SQraIxMtqjCwQU/MCrNMZgjqE3GuuDih406yIIhQyiQyinpECCoTGw6M0puUKIoArNvlDCoD6ksCtGARkSCItAAgliPYMceOA+hjTCwqcxKlwIDjUXsmNJp4xw08sxpDAjpy7KSHE3LWoqEbcE2jDIBv/yDCrhATBVGaOA2VZY4RFVDtkwKzAKgKGrFYrcw4PppCiAB+jeSOAHoi6YYaG9sLCExQdqOoSBlpYaIDxVeIgA10A+0MCgPSb4oDlViEiAoQvCCyQCgtBUBYupKrjToA+E+0CkFfJTxYjV3gAtDQRgqImFXw16w4PwDnFPlSFqpaPcMVW5Y9VBcROUCgYWoqKAJysQsAoEKP0owYqkIGA1rYIwbCEjylUlgSEWCgE0didYKAgHGBoiX4MwyGEhNgzocNuFDeLBYRu0PcSAmmD40CAWNtWKDhYYKKCC3j6olSEkLC5KRNgSENCDG08qAFcGUrwLUoMeeSCxDyKu97j/lC06dqELBPwgBB4JZkiLAujVKgKPFnqDgBFVQcCzEWQutuQeMGCIjQGEu6Dsn0c2ouRcHZ6haIMS0OyEGBayAXCtArHBAPf2IOC/iozw2YUI1lyzibQ1+Nho6ETF1fAzLW9CJCQGOOHJqW2jYwk5jNBWiqsNytqgCtxWpQ2v5TQAcawSIIIhOgrQDAHIVWl7oSFK5oHiuwjw6YLNf8Z1b4Zy8BtxwQ+SW3apu8LujTEIYKNBnzXgOisNEE6jAOh4YEDghT5gnqElEiigy9RZ64FeKTI2CHZkCUgDiTJX7uKXgM/lpCBP4xEB4GAQ4i3keAZJ3kLixpA0DCBV0ZPP//T4Zj3DYc8zQSDVEqblpYo4Lg1vGEBMIuezEPCNIelbyPqgA5cEqmIFE8rKIWBgwPwt51YGcZ2+YqeK2W0rAa/6nwEOkZUQiW0hKbBLDxy2LYohQFAjKBwRfaaKHjygEwvR1UI0sDMkONEgSODb8kLIkAQICgtP5MoQUCeHGqmCVg1aGBU0mBUOqO9ozVMaFgbgmRqaMW1BHM0YBCCFR9ABBglIGw8KkLZAMOBlqjiBzPzQAwMgrCJpqIAonxADopSgCsACHN0E9IgKAG6SuPpBApZAqS3gDHkPCM8djFAANz0KOiJZlMR4mEE3SeEDUjDP+LIShBB8bgWrdEoCfP/CBjuoIgYImA4MHnCVRRTpEONZyBIEoJkgPCBtmrEBAwryiCZQyw+KYiRrpGADnxBBQDqqCT8X+RQnqeIJZKpIF5CABTAIaiFj2E2KwJAjg5ihDGNIGz8N0oMKBOILzMRKFYLgk3gZpApEsAv40nAV8JmhJl9IgwtVkQIGJMAABKjAg7y0JimgbltGkIKhHAXRiPIgCKgZg0rT9lCX9mgJVeBPGnow1Bp2YQvOqmdVTSNDyLwBcotgAwZsZ1WwhrUrGK3MrtJEQLGmVa0Xw6piLgA/VZhwrXNVawoSYFPFpMEGdHjEI8aAP7oGtp5jKINwKPOGFQpWsYtlbGMd+1hAyEZWspOlbGUte1nMZlazm+VsZz37WdCGVrSjJW1pTXta1KZWtatlbWtd+1rYxla2s6VtbW17W9zmVre75WxAAAA7"
result_available = threading.Event()


def help_menu():
    # print "Open web browser to http://www.dur.ac.uk/m.j.r.bordewich/LMC.html!"
    webbrowser.open('http://community.dur.ac.uk/m.j.r.bordewich/LMC.html', new=2)


def is_number(s):
    try:
        int(s)
        if int(s) >= 0:
            return True
        else:
            return False
    except ValueError:
        return False


class Assembler:
    def __init__(self, assembly_file, is_data=False):
        if is_data:
            self.data = assembly_file
        else:
            try:
                myfile = open(assembly_file, "r")
                self.data = myfile.read().replace('\r', '').replace('\n\n', '\n')
                myfile.close()
            except IOError:
                self.data = ''
        self.logText = ""
        self.mnemonics = ['HLT', 'ADD', 'SUB', 'STO', 'NUL', 'LDA', 'BR', 'BRZ', 'BRP', 'IN', 'OUT', 'DAT']

    def compile(self):
        compile_failed = False
        errors = ''
        boxes_to_use = dict()
        machine_code = array.array('i')
        for i in range(500):
            machine_code.append(0)
        prog = self.data
        lines = prog.split('\n')
        next_mailbox = 0
        self.logText = "\nAssigning mailboxes:\n"
        # Loop through to assign mailboxes
        for i in range(len(lines)):
            # print(lines[i])
            lines[i] = lines[i].strip('\r')
            if lines[i] == '':
                # print('Blank')
                self.logText = self.logText + 'Line ' + str(i) + ', blank line\n'
            elif lines[i].lstrip().startswith('#'):
                self.logText = self.logText + 'Line ' + str(i) + ': comment \'' + lines[i] + '\'\n'  # print('Comment')
            else:
                if lines[i][0] == '\t' or lines[i][0] == ' ':
                    lines[i] = '_' + str(i) + ' ' + lines[i] + ' -'
                else:
                    lines[i] = lines[i] + ' -'
                words = lines[i].split()
                if len(words) < 2:
                    print(('Amended line:', lines[i]))
                    print(words)
                    pass
                elif words[1] == '-':
                    self.logText = self.logText + 'Line ' + str(i) + ': no instruction: ' + lines[i] + '\n'  # errors=errors+'Line '+str(i)+', no instruction: '+lines[i]+'\n'  # CompileFailed=True
                elif words[1] not in self.mnemonics:
                    self.logText = self.logText + 'Line ' + str(i) + ': Bad instruction: \'' + words[1] + '\'\n'
                    errors = errors + 'Line ' + str(i) + ': Bad instruction: \'' + words[1] + '\'\n'
                    compile_failed = True
                else:
                    if words[0] in boxes_to_use:
                        self.logText = self.logText + 'Error - code uses label "' + words[0] + '" twice, second occurrence in line ' + str(i) + '\n'
                        errors = errors + 'Error - code uses label "' + words[0] + '" twice, second occurrence in line ' + str(i) + '\n'
                        compile_failed = True
                    else:
                        boxes_to_use[words[0]] = next_mailbox
                        next_mailbox += 1
                    if next_mailbox > 100:
                        self.logText = self.logText + 'Error - code using more than 100 mailboxes\n'
                        errors = errors + 'Error - code using more than 100 mailboxes\n'
                        compile_failed = True
                    self.logText = self.logText + '{:8} {:3} {:8} - use mailbox {:02d}\n'.format(words[0], words[1], words[2], boxes_to_use[words[0]])
        # loop through to write codes
        self.logText = self.logText + '\n\nWriting Machine Code:\n'
        for i in range(len(lines)):
            if lines[i] == '':
                pass
            elif lines[i].lstrip().startswith('#'):
                pass
            else:
                words = lines[i].split()
                if words[1] == '-':
                    pass
                elif words[1] not in self.mnemonics:
                    pass
                else:
                    if (self.mnemonics.index(words[1]) == 0):
                        machine_code[boxes_to_use[words[0]]] = 0
                        self.logText = self.logText + 'Line ' + str(i) + ': Machine code \'{:03d}\' in mailbox '.format(0) + str(boxes_to_use[words[0]]) + '\n'
                    elif (self.mnemonics.index(words[1]) == 9):
                        machine_code[boxes_to_use[words[0]]] = 901
                        self.logText = self.logText + 'Line ' + str(i) + ': Machine code \'{:03d}\' in mailbox '.format(901) + str(boxes_to_use[words[0]]) + '\n'
                    elif (self.mnemonics.index(words[1])) == 10:
                        machine_code[boxes_to_use[words[0]]] = 902
                        self.logText = self.logText + 'Line ' + str(i) + ': Machine code \'{:03d}\' in mailbox '.format(902) + str(boxes_to_use[words[0]]) + '\n'
                    elif (self.mnemonics.index(words[1])) == 11:
                        if len(words) > 1:
                            if is_number(words[2]):
                                machine_code[boxes_to_use[words[0]]] = (int(words[2]) % 1000)
                                self.logText = self.logText + 'Line ' + str(i) + ': Machine code \'{:03d}\' in mailbox '.format((int(words[2]) % 1000)) + str(boxes_to_use[words[0]]) + '\n'
                    else:
                        if len(words) > 2:
                            if words[2] in boxes_to_use:
                                machine_code[boxes_to_use[words[0]]] = (100 * self.mnemonics.index(words[1]) + boxes_to_use[words[2]])
                                self.logText = self.logText + 'Line ' + str(i) + ': Machine code \'{:03d}\' in mailbox '.format((100 * self.mnemonics.index(words[1]) + boxes_to_use[words[2]])) + str(boxes_to_use[words[0]]) + '\n'
                            else:
                                if words[2] == '-':
                                    self.logText = self.logText + 'Line ' + str(i) + ': Error - no label\n'
                                    errors = errors + 'Line ' + str(i) + ': Error - no label\n'
                                else:
                                    self.logText = self.logText + 'Line ' + str(i) + ': Error - label \'' + str(words[2]) + '\' not found\n'
                                    errors = errors + 'Line ' + str(i) + ': Error - label \'' + str(words[2]) + '\' not found\n'
                                compile_failed = True
        # print(self.logText)
        if not compile_failed:
            return True, machine_code[:100], next_mailbox
        else:
            return False, errors, next_mailbox


class HyperlinkManager:
    def __init__(self, text):
        self.text = text
        self.text.tag_config("hyper", foreground="blue", underline=1)
        self.text.tag_bind("hyper", "<Enter>", self._enter)
        self.text.tag_bind("hyper", "<Leave>", self._leave)
        self.text.tag_bind("hyper", "<Button-1>", self._click)
        self.reset()

    def reset(self):
        self.links = {}

    def add(self, action):
        # add an action to the manager.  returns tags to use in
        # associated text widget
        tag = "hyper-%d" % len(self.links)
        self.links[tag] = action
        return "hyper", tag

    def _enter(self, event):
        self.text.config(cursor="hand2")

    def _leave(self, event):
        self.text.config(cursor="")

    def _click(self, event):
        for tag in self.text.tag_names(tk.CURRENT):
            if tag[:6] == "hyper-":
                self.links[tag]()
                return


class MyDialog:
    def __init__(self, parent, controller):
        self.controller = controller
        top = self.top = tk.Toplevel(parent)
        self.frame = tk.Frame(top)
        self.frame.pack()
        tk.Label(self.frame, text="Value").pack()
        self.e = tk.Entry(self.frame)
        self.e.pack(padx=5)
        b = tk.Button(self.frame, text="OK", command=self.ok)
        self.e.bind("<Return>", self.on_return)
        self.e.focus_set()
        b.pack(pady=5)

    def ok(self):
        # print("value is", self.e.get())
        # app.calcEnter(int(self.e.get()))
        if len(self.e.get()) > 0:
            if is_number(self.e.get()[-3:]):
                self.controller.model.put_in_intray(int(self.e.get()[-3:]))
                self.top.destroy()
            else:
                self.e.delete(0, tk.END)

    def on_return(self, event):
        # print("value is", self.e.get())
        # app.calcEnter(int(self.e.get()))
        if len(self.e.get()) > 0 and not is_number(self.e.get()):
            self.e.delete(0, tk.END)
        if len(self.e.get()) > 0 and is_number(self.e.get()):
            self.controller.model.put_in_intray(int(self.e.get()[-3:]))
            self.top.destroy()


class LogGUI:
    def __init__(self, parent, message):
        frm = self.frm = tk.Toplevel(parent)
        frm.title('Compiler Log')
        button_frame = tk.Frame(frm)
        button_frame.pack(side=tk.TOP)
        tk.Button(button_frame, text='Close', command=self.on_close).pack(side=tk.LEFT)
        self.text = tk.Text(frm, height=50, width=50, background='white')
        # put a scroll bar in the frame
        self.scroll = tk.Scrollbar(frm, command=self.text.yview)
        self.text.configure(yscrollcommand=self.scroll.set)

        # pack everything
        self.text.pack(side=tk.LEFT, expand=1, fill=tk.BOTH)
        # self.text.bind("<<Paste>>", self.scrolldown)
        self.scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.text.focus_set()
        self.text.config(font=('courier', 12, 'normal'))
        self.text.insert(tk.END, message)
        self.text.config(state=tk.DISABLED)

    def on_close(self):
        self.frm.destroy()
        return ""


class AssemblerGUI:
    def __init__(self, parent):

        frm = self.frm = tk.Toplevel(parent)
        frm.title('LMC Assembly Editor')
        button_frame = tk.Frame(frm)
        button_frame.pack(side=tk.TOP)
        tk.Button(button_frame, text='Open', command=self.on_load).pack(side=tk.LEFT, pady=5)
        tk.Button(button_frame, text='Save', command=self.on_save).pack(side=tk.LEFT)
        tk.Button(button_frame, text='Close', command=self.on_close).pack(side=tk.LEFT)
        tk.Button(button_frame, text='Compile', command=self.on_compile).pack(side=tk.LEFT)
        tk.Button(button_frame, text='Show log', command=self.on_log).pack(side=tk.LEFT)
        self.text = tk.Text(frm, height=50, width=50, background='white')
        self.lineNos = tk.Text(frm, height=50, width=3, background='white')
        # put a scroll bar in the frame
        self.scroll = tk.Scrollbar(frm, command=self.yview)
        self.text.configure(yscrollcommand=self.scroll.set)
        for i in range(100):
            self.lineNos.insert(tk.END, ' {:02d}\n'.format(i))
        self.lineNos.config(state=tk.DISABLED)

        # pack everything
        self.lineNos.pack(side=tk.LEFT, fill=tk.Y)
        self.text.pack(side=tk.LEFT, expand=1, fill=tk.BOTH)
        self.scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.text.focus_set()
        if (is_windows):
            self.text.config(font=('courier', 10, 'normal'))
            self.lineNos.config(font=('courier', 10, 'normal'))
        else:
            self.text.config(font=('courier', 12, 'normal'))
            self.lineNos.config(font=('courier', 12, 'normal'))
        self.text.insert(tk.END, app.compileText)
        self.set_line_nos()

    def yview(self, *args):
        # apply(self.lineNos.yview, args)
        self.text.yview(*args)

    def set_line_nos(self):
        self.lineNos.config(state=tk.NORMAL)
        self.text.see(self.text.index('@0,0'))
        for i in range(1, self.text.cget('height') * 20, 12):
            the_index = self.lineNos.index('@0,' + str(i))
            visiblechar = int(self.text.index('@0,' + str(i)).split('.')[0])
            if (visiblechar < 100):
                set_to = ' {:02d}'.format(visiblechar - 1)
            else:
                set_to = '{:03d}'.format(visiblechar - 1)
            # print(i,self.text.index('@0,'+str(i)),the_index,set_to, ' at ',the_index.split('.')[0]+'.end')
            self.lineNos.delete(the_index)
            self.lineNos.delete(the_index)
            self.lineNos.delete(the_index)
            self.lineNos.insert(the_index, set_to)
        self.lineNos.config(state=tk.DISABLED)
        self.frm.after(300, self.set_line_nos)

    def on_save(self):
        filename = filedialog.asksaveasfilename()
        if filename:
            if filename.count('.') == 0:
                filename = filename + '.txt'
            alltext = self.text.get('1.0', tk.END + '-1c')
            open(filename, 'w').write(alltext)

    def on_load(self):
        myfile = select_file("LMC assembly")
        if myfile is not None and myfile != '':
            data = open(myfile, 'r').read()
            data = data.replace('\r', '')
            data = data.replace('\n\n', '\n')
            self.text.delete(1.0, tk.END)
            self.text.insert(tk.END, data)
        self.set_line_nos()

    def on_compile(self):
        my_assembler = Assembler(self.text.get(1.0, 'end'), True)
        success, result, num_mailboxes = my_assembler.compile()
        if success:
            if (tkinter.messagebox.askyesno("Compile Result", "Compile successful\n\n Would you like to view the compile log?", default='no')):
                LogGUI(root, my_assembler.logText)
            app.compileText = self.text.get(1.0, tk.END)
            app.logText = my_assembler.logText
            self.frm.destroy()
            for i in range(len(result)):
                app.model.mailboxes[i].set(result[i])
                app.model.reset_program_counter()
            if app.model.minion.speed == 30:
                app.model.controller.refresh_all()
            return ""
        else:
            # messagebox.showinfo("hello", "Compile failed:\n\n"+errors)
            app.logText = my_assembler.logText
            tkinter.messagebox.showinfo("hello", "Compile failed:\n\n" + result)

    def on_close(self):
        app.compileText = self.text.get(1.0, tk.END)
        self.frm.destroy()
        return ""

    def on_log(self):
        # messagebox.showinfo("hello", "Compile log:\n\n"+app.logText)
        # tkMessageBox.showinfo("hello", "Compile log:\n\n"+app.logText,font="Courier")
        LogGUI(root, app.logText)


def about():
    AboutGUI(root)


def bug_report():
    webbrowser.open('mailto:m.j.r.bordewich@durham.ac.uk?subject=Little Minion Computer - Bug report')


class Observable:
    def __init__(self, initial_value=None):
        self.data = initial_value
        self.callbacks = {}

    def add_callback(self, func):
        self.callbacks[func] = 1

    def del_callback(self, func):
        del self.callback[func]

    def _docallbacks(self):
        for func in self.callbacks:
            func(self.data)

    def set(self, data):
        self.data = data
        self._docallbacks()

    def seti(self, data, i):
        self.data[i] = data
        self._docallbacks()

    def geti(self, i):
        return self.data[i]

    def get(self):
        return self.data

    def pop(self, index):
        result = self.data.pop(index)
        self._docallbacks()
        return result

    def append(self, value):
        self.data.append(value)
        self._docallbacks()

    def unset(self):
        self.data = None
        self._docallbacks()


class AboutGUI:
    def __init__(self, parent):
        frm = self.frm = tk.Toplevel(parent)
        frm.title('About')
        self.frame = tk.Frame(frm)
        self.frame.pack()
        self.logoImage = tk.PhotoImage(data=DU_logo)
        self.logo = tk.Label(self.frame, image=self.logoImage)
        self.logo.photo = self.logoImage
        self.logo.pack(side=tk.TOP)
        self.text = tk.Text(self.frame, height=13, width=40, font="Times 15", wrap=tk.WORD)
        if (is_windows):
            self.text = tk.Text(self.frame, height=13, width=50, font="Times 11", wrap=tk.WORD)
        hyperlink = HyperlinkManager(self.text)
        self.text.insert(1.0, 'A Little Minion Computer Simulator developed by ')
        self.text.insert(tk.INSERT, 'Dr Magnus Bordewich', hyperlink.add(self.weblink))
        self.text.insert(tk.INSERT,
                         ' of the Department of Computer Science, Durham University, U.K.\n\nThe Little Minion Computer is a conceptual model of a CPU created by Dr. Stuart Madnick of M.I.T.. This simulation is based on the description found in the book: The Architecture of Computer Hardware and System Software: An Information Technology Approach, 3rd edition, by Irv Englander.\n\nFor more information see ')
        self.text.insert(tk.INSERT, 'Online Help.', hyperlink.add(self.weblinkhelp))
        # with open('about.txt', 'r') as f:
        #    aboutText = f.read()
        # self.text.insert(INSERT, aboutText)
        self.text.config(state=tk.DISABLED)
        self.text.pack(side=tk.TOP)
        self.closeBut = tk.Button(frm, text='Close', command=self.on_close)
        self.closeBut.pack(side=tk.TOP)
        # CENTER WINDOW
        w = self.frm.winfo_screenwidth()
        h = self.frm.winfo_screenheight()
        frmsize = (408, 444)  # tuple(int(_) for _ in frm.geometry().split('+')[0].split('x'))
        x = w // 2 - frmsize[0] // 2
        y = h // 2 - frmsize[1] // 2
        self.frm.geometry("%dx%d+%d+%d" % (frmsize + (x, y)))
        self.frm.bind("<Enter>", self.resize)

    def resize(self, event):
        pass  # self.frm.geometry("%dx%d+%d+%d" % (frmsize + (x+100, y+100)))

    def email(self):
        webbrowser.open('mailto:m.j.r.bordewich@durham.ac.uk?subject=Little Minion Computer')

    def weblink(self):
        webbrowser.open('http://community.dur.ac.uk/m.j.r.bordewich/', new=2)

    def weblinkhelp(self):
        webbrowser.open('http://community.dur.ac.uk/m.j.r.bordewich/LMC.html', new=2)

    def on_close(self):
        self.frm.destroy()
        return ""


class Controller:
    def __init__(self, root):
        self.root = root
        self.askedToStop = False
        # noinspection PyPep8
        self.compileText = '# Enter assembler code here\n#\n# To add comments begin lines with #\n# Code lines have 3 entries separated by tabs\n# > First an optional label,\n# > second an instruction mnemonic, and \n# > third an address label if required.\n#\n# Valid mnemonics are:\n# HLT, ADD, SUB, STO, LDA,\n# BR, BRZ, BRP, IN, OUT, DAT\n'
        self.logText = ""
        self.model = LMC(self)
        self.animations_on = True
        self.buttonsIsolatedforBatch = False
        self.shutDownBatch = False
        self.d = {}
        for k in range(100):
            func = 'mbc' + str(k)
            self.d[func] = partial(self.mailbox_ei_changed, index=k)
        for i in range(100):
            pass
            func = 'mbc' + str(i)
            self.model.mailboxes[i].add_callback(self.d[func])
        self.model.calculator.add_callback(self.calculator_changed)
        self.model.PC.add_callback(self.program_counter_changed)
        self.model.intray.add_callback(self.intray_changed)
        self.model.outtray.add_callback(self.outtray_changed)
        self.model.negativeFlag.add_callback(self.negflag_changed)
        self.model.minion.operation.add_callback(self.operation_changed)
        self.model.minion.mar.add_callback(self.mar_changed)
        self.model.minion.mdr.add_callback(self.mdr_changed)
        self.model.minion.position.add_callback(self.littleman_position_changed)
        self.model.minion.halted.add_callback(self.little_man_halted_changed)

        self.view1 = View(root)

        self.refresh_all()
        self.view1.FEbutton.config(command=self.fetch_execute_button_clicked)
        self.view1.Runbutton.config(command=self.run_button_clicked)
        self.view1.animation_check.config(command=self.animation_toggle)
        self.view1.SpeedSlider.config(command=self.speed_change)
        self.view1.ResetButton.config(command=self.reset_program_counter_button_clicked)
        self.view1.ResetAllButton.config(command=self.reset_all_button_clicked)
        self.view1.entry.bind("<Return>", self.add_input_return)
        self.view1.PCTray.bind("<Return>", self.program_counter_entry)
        self.view1.PCTray.bind("<FocusOut>", self.program_counter_entry)

        # self.view1.onestep.config(command=self.model.dump_state)
        for i in range(100):
            self.view1.memorycells[i].bind("<Return>", self.mailbox_entry)
            self.view1.memorycells[i].bind("<FocusOut>", self.mailbox_entry)
        self.calcposition = (self.view1.calcframe.winfo_x(), self.view1.calcframe.winfo_y() + self.view1.calcframe.winfo_height())
        self.PCposition = (self.view1.PCframe.winfo_x(), self.view1.PCframe.winfo_y() - self.view1.LMframe.winfo_height())
        self.outputposition = (self.view1.leftframe.winfo_x() + self.view1.leftframe.winfo_width(), self.view1.leftframe.winfo_y() + self.view1.entryframe.winfo_height())
        self.inputposition = (self.view1.leftframe.winfo_x() + self.view1.leftframe.winfo_width(), self.view1.leftframe.winfo_y())

    def isolate_buttons_for_batch(self, startorend):
        if startorend == 'start':
            self.view1.disable_fetch_execute_buttons()
            self.view1.ResetAllButton.config(state='disabled')
            self.buttonsIsolatedforBatch = True
            self.view1.Runbutton['text'] = "Stop"
        else:
            self.view1.enable_fetch_execute_buttons()
            self.view1.ResetAllButton.config(state='normal')
            self.buttonsIsolatedforBatch = False
            self.view1.Runbutton['text'] = "Run"
            self.shutDownBatch = False

    def mailboxposition(self, index):
        return (self.view1.memory.winfo_x() - 5 - self.view1.LMframe.winfo_width(), self.view1.memory.winfo_y() + (self.view1.memory.winfo_height() - self.view1.LMframe.winfo_height()) * (index // 10) // 10)

    def fetch_execute_button_clicked(self):
        self.view1.disable_fetch_execute_buttons()
        self.model.minion.fetch()
        self.model.minion.execute()
        self.model.minion.halted.set(True)
        self.view1.enable_fetch_execute_buttons()
        if self.model.minion.speed == 30:
            self.refresh_all()

    def reset_all_button_clicked(self):
        self.model.reset_all()
        if self.model.minion.speed == 30:
            self.refresh_all_except_mailboxes()

    def reset_program_counter_button_clicked(self):
        self.model.reset_program_counter()
        if self.model.minion.speed == 30:
            self.refresh_all_except_mailboxes()

    def run_button_clicked(self):
        if self.buttonsIsolatedforBatch:
            self.shutDownBatch = True
        else:
            self.askedToStop = True
            if self.model.minion.halted.get():
                self.askedToStop = False
                self.view1.Runbutton['text'] = "Stop"
                self.view1.disable_fetch_execute_buttons()
                self.batchlog('Running...')
                self.model.run(0)

            else:
                self.model.minion.halted.set(True)
                self.view1.Runbutton['text'] = "Run"
                self.view1.enable_fetch_execute_buttons()
                if self.model.minion.speed == 30:
                    self.refresh_all()

    def little_man_halted_changed(self, value):
        if not self.buttonsIsolatedforBatch:
            if value:
                self.view1.Runbutton['text'] = "Run"
                self.view1.enable_fetch_execute_buttons()
            else:
                self.view1.Runbutton['text'] = "Stop"
                self.view1.disable_fetch_execute_buttons()

    def log(self, text, force_log=False):
        if not self.model.batchProcessing:
            if self.model.minion.speed < 3 or (self.model.minion.speed <= 24 and force_log):
                self.view1.text.insert(tk.END, '\n' + text)
                self.view1.text.yview(tk.END)
                self.root.update()

    def batchlog(self, text):
        self.view1.text.insert(tk.END, '\n' + text)
        self.view1.text.yview(tk.END)

    def runninglog(self, text, first=False):
        if not first:
            self.view1.text.delete('end-1l', 'end')
        self.view1.text.insert(tk.END, '\n' + text)
        self.view1.text.yview(tk.END)

    def add_input_return(self, value):
        self.model.put_in_intray(self.view1.entry.get())
        self.view1.entry.delete(0, tk.END)

    def program_counter_entry(self, value):
        self.model.PC.set(int(self.view1.PCTray.get()) % 100)

    def mailbox_entry(self, event):
        index = int(str(event.widget).split(".")[-1][3:])
        try:
            self.model.set_mailbox(index, (int(event.widget.get()) % 1000))
        except ValueError:
            self.model.set_mailbox(index, (self.model.get_mailbox(index)))

    def speed_change(self, value):
        if int(value) < 4:
            self.model.minion.speed = int(value)
        else:
            self.model.minion.speed = int(value) * 6

    def animation_toggle(self):
        if self.view1.CheckVar.get() == 1:
            # print("Animation is on")
            self.animations_on = True  # root.geometry('1110x' + str(775) + '+50+0')

        if self.view1.CheckVar.get() == 0:
            # print("Animation is off")
            self.animations_on = False  # lm.moveTo(self.calcframe.winfo_x(), self.calcframe.winfo_y() + self.calcframe.winfo_height())

    def refresh_all(self):
        if self.model.minion.speed == 30:
            self.model.minion.speed = 29
        self.calculator_changed(self.model.calculator.get())
        self.program_counter_changed(self.model.PC.get())
        self.negflag_changed(self.model.negativeFlag.get())
        self.intray_changed(self.model.intray.get())
        self.mar_changed(self.model.minion.mar.get())
        self.mdr_changed(self.model.minion.mdr.get())
        self.operation_changed((self.model.minion.operation.get()))
        self.little_man_halted_changed(self.model.minion.halted.get())
        for i in range(100):
            if self.view1.memorycells[i].get() == '':
                self.mailbox_ei_changed(self.model.mailboxes[i].get(), i)
            elif int(self.view1.memorycells[i].get()) != self.model.mailboxes[i].get():
                self.mailbox_ei_changed(self.model.mailboxes[i].get(), i)
        self.root.update()
        if self.model.minion.speed == 29:
            self.model.minion.speed = 30

    def refresh_all_except_mailboxes(self):
        if self.model.minion.speed == 30:
            self.model.minion.speed = 29
        self.calculator_changed(self.model.calculator.get())
        self.little_man_halted_changed(self.model.minion.halted.get())
        self.program_counter_changed(self.model.PC.get())
        self.negflag_changed(self.model.negativeFlag.get())
        self.intray_changed(self.model.intray.get())
        self.mar_changed(self.model.minion.mar.get())
        self.mdr_changed(self.model.minion.mdr.get())
        self.operation_changed((self.model.minion.operation.get()))
        self.root.update()
        if self.model.minion.speed == 29:
            self.model.minion.speed = 30

    def mailbox_ei_changed(self, value, index=None):
        if (not self.model.batchProcessing) and self.model.minion.speed < 30:
            self.view1.set_mailbox_ei(index, value)  # self.root.update()

    def calculator_changed(self, calc):
        if not self.model.batchProcessing and self.model.minion.speed < 30:
            self.view1.set_calculator(calc)
            self.root.update()

    def program_counter_changed(self, program_counter):
        if not self.model.batchProcessing and self.model.minion.speed < 30:
            self.view1.set_pc(program_counter)
            self.root.update()

    def intray_changed(self, intray):
        if not self.model.batchProcessing:
            self.view1.set_intray(intray)
            self.root.update()

    def outtray_changed(self, outtray):
        if not False:  # self.model.batchProcessing:
            self.view1.set_outtray(outtray)
            self.root.update()

    def negflag_changed(self, neg_flag):
        if not self.model.batchProcessing and self.model.minion.speed < 30:
            self.view1.set_negflag(neg_flag)
            self.root.update()

    def mar_changed(self, mar):
        if not self.model.batchProcessing and self.model.minion.speed < 30:
            self.view1.set_mar(mar)
            self.root.update()

    def mdr_changed(self, mdr):
        if not self.model.batchProcessing and self.model.minion.speed < 30:
            self.view1.set_mdr(mdr)
            self.root.update()

    def operation_changed(self, operation):
        if not self.model.batchProcessing and self.model.minion.speed < 30:
            self.view1.set_instruction(operation)
            self.root.update()

    def littleman_position_changed(self, position):
        if self.animations_on and not self.model.batchProcessing and self.model.minion.speed < 30:
            self.view1.set_lm_position(position)
            self.root.update()


class LM:
    def __init__(self, parent):
        self.mdr = Observable(0)
        self.mar = Observable(0)
        self.operation = Observable("HLT")
        self.position = Observable((150, 150))
        self.halted = Observable(True)
        self.LMC = parent
        self.speed = 1
        self.framerate = 30
        self.lastfetch = 0

    def move_to(self, newxy):
        if self.speed < 24 and not self.LMC.batchProcessing:
            steps = max(3, int(self.framerate // self.speed))
            oldxy = self.position.get()
            totaldist = (abs(oldxy[0] - newxy[0]) * abs(oldxy[0] - newxy[0]) + abs(oldxy[1] - newxy[1]) * abs(oldxy[1] - newxy[1])) ** 0.5
            dist = totaldist // steps
            if totaldist < 100:
                steps = steps * 2
            starttime = time.time()
            for i in range(steps + 1):
                newx = ((steps - i) * oldxy[0] + newxy[0] * i) // steps
                newy = ((steps - i) * oldxy[1] + newxy[1] * i) // steps
                self.position.set((newx, newy))
            timetaken = time.time() - starttime
            if self.LMC.controller.animations_on and totaldist > 100:
                self.framerate = steps // timetaken

    def fetch(self):

        self.halted.set(False)
        self.LMC.controller.log('Fetching')
        self.move_to(self.LMC.controller.PCposition)
        self.mar.set(self.LMC.get_program_counter())
        self.LMC.controller.log('   Program counter is at ' + str(self.mar.get()))
        if self.speed == 1 and not self.LMC.batchProcessing:
            time.sleep(0.5)
        self.LMC.increment_program_counter()
        self.LMC.controller.log('   Incrementing program counter')
        if self.speed == 1 and not self.LMC.batchProcessing:
            time.sleep(0.5)
        self.move_to(self.LMC.controller.mailboxposition(self.mar.get()))
        self.lastfetch = self.mar.get()
        self.mdr.set(self.LMC.get_mailbox(self.mar.get()))
        self.LMC.controller.log('   Instruction is ' + str(self.mdr.get()))
        if self.speed == 1 and not self.LMC.batchProcessing:
            time.sleep(0.5)
        opcode = self.mdr.get() // 100
        self.mar.set(self.mdr.get() - opcode * 100)
        self.LMC.controller.log('   Opcode is ' + str(opcode) + '; Address is ' + str(self.mar.get()))
        if self.speed == 1 and not self.LMC.batchProcessing:
            time.sleep(0.5)
        if opcode == 0:
            self.operation.set("HLT")
        elif opcode == 1:
            self.operation.set("ADD")
        elif opcode == 2:
            self.operation.set("SUB")
        elif opcode == 3:
            self.operation.set("STO")
        elif opcode == 4:
            self.operation.set("ERR")
        elif opcode == 5:
            self.operation.set("LDA")
        elif opcode == 6:
            self.operation.set("BR")
        elif opcode == 7:
            self.operation.set("BRZ")
        elif opcode == 8:
            self.operation.set("BRP")
        elif opcode == 9:
            self.operation.set("I/O")  # print('LM operation:'+self.operation+' LM addr:'+str(self.mar))
        self.LMC.controller.log('   Operation is ' + self.operation.get() + '')
        if self.speed == 1 and not self.LMC.batchProcessing:
            time.sleep(0.5)

    def execute(self):
        preface = ''
        if self.speed == 3 or self.speed == 24:
            preface = '   [' + str(self.lastfetch).zfill(2) + ']'

        if self.speed == 1 and not self.LMC.batchProcessing:
            time.sleep(0.5)

        self.LMC.controller.log('Executing')
        if self.speed == 1 and not self.LMC.batchProcessing:
            time.sleep(0.5)
        if self.operation.get() == "HLT":
            self.halted.set(True)
            self.LMC.controller.log(preface + '   HLT', True)
            if self.speed == 30:
                self.LMC.controller.refresh_all()
        elif self.operation.get() == "ADD":
            self.move_to(self.LMC.controller.mailboxposition(self.mar.get()))
            self.mdr.set(self.LMC.get_mailbox(self.mar.get()))
            self.move_to(self.LMC.controller.calcposition)
            self.LMC.calculator.set((self.LMC.calculator.get() + self.mdr.get()) % 1000)
            self.LMC.controller.log(preface + '   ADD from mailbox ' + str(self.mar.get()), True)
        elif self.operation.get() == "SUB":
            self.move_to(self.LMC.controller.mailboxposition(self.mar.get()))
            self.mdr.set(self.LMC.get_mailbox(self.mar.get()))
            self.move_to(self.LMC.controller.calcposition)
            new_val = self.LMC.calculator.get() - self.mdr.get()
            if new_val < 0:
                self.LMC.negativeFlag.set(True)
            self.LMC.calculator.set((new_val) % 1000)
            self.LMC.controller.log(preface + '   SUB from mailbox ' + str(self.mar.get()), True)
        elif self.operation.get() == "STO":
            self.move_to(self.LMC.controller.calcposition)
            self.mdr.set(self.LMC.calculator.get())
            self.move_to(self.LMC.controller.mailboxposition(self.mar.get()))
            self.LMC.set_mailbox(self.mar.get(), self.mdr.get())
            self.LMC.controller.log(preface + '   STO in mailbox ' + str(self.mar.get()), True)
        elif self.operation.get() == "ERR":
            self.LMC.controller.log(preface + '   ERROR', True)
            pass
        elif self.operation.get() == "LDA":
            self.move_to(self.LMC.controller.mailboxposition(self.mar.get()))
            self.mdr.set(self.LMC.get_mailbox(self.mar.get()))
            self.move_to(self.LMC.controller.calcposition)
            self.LMC.calculator.set(self.mdr.get())
            self.LMC.negativeFlag.set(False)
            self.LMC.controller.log(preface + '   LDA from mailbox ' + str(self.mar.get()), True)
        elif self.operation.get() == "BR":
            self.move_to(self.LMC.controller.PCposition)
            self.LMC.set_program_counter(self.mar.get())
            self.LMC.controller.log(preface + '   BR to ' + str(self.mar.get()), True)
        elif self.operation.get() == "BRZ":
            self.move_to(self.LMC.controller.calcposition)
            if (self.LMC.calculator.get() == 0):
                self.move_to(self.LMC.controller.PCposition)
                self.LMC.set_program_counter(self.mar.get())
                self.LMC.controller.log(preface + '   BRZ to ' + str(self.mar.get()), True)
            else:
                self.LMC.controller.log(preface + '   BRZ not taken', True)
        elif self.operation.get() == "BRP":
            self.move_to(self.LMC.controller.calcposition)
            if not self.LMC.negativeFlag.get():
                self.move_to(self.LMC.controller.PCposition)
                self.LMC.set_program_counter(self.mar.get())
                self.LMC.controller.log(preface + '   BRP to ' + str(self.mar.get()), True)
            else:
                self.LMC.controller.log(preface + '   BRZ not taken', True)
        elif self.operation.get() == "I/O":
            if self.mar.get() == 1:
                self.move_to(self.LMC.controller.inputposition)
                input = self.LMC.read_intray()
                if input != 'error':
                    self.mdr.set(input)
                else:
                    d = MyDialog(root, self.LMC.controller)
                    root.wait_window(d.top)
                    self.mdr.set(self.LMC.read_intray())
                self.move_to(self.LMC.controller.calcposition)
                self.LMC.calculator.set(self.mdr.get())
                self.LMC.controller.log(preface + '   IN ' + str(self.mdr.get()), True)
            elif self.mar.get() == 2:
                self.move_to(self.LMC.controller.calcposition)
                self.mdr.set(self.LMC.calculator.get())
                self.move_to(self.LMC.controller.outputposition)
                self.LMC.put_in_outtray(self.mdr.get())
                self.LMC.controller.log(preface + '   OUT ' + str(self.mdr.get()), True)
        self.LMC.controller.log(' ')
        if self.speed == 1 and not self.LMC.batchProcessing:
            time.sleep(1.0)


class LMC:
    def __init__(self, parent):
        self.mailboxes = []
        for i in range(100):
            self.mailboxes.append(Observable(0))
        self.controller = parent
        self.PC = Observable(0)
        self.intray = Observable([])
        self.outtray = Observable([])
        self.calculator = Observable(0)
        self.negativeFlag = Observable(False)
        self.minion = LM(self)
        self.batchProcessing = False
        self.inputAlert = Observable(False)

    def dump_state(self):
        print("Mailboxes")
        data = []
        for i in range(100):
            data.append(self.mailboxes[i].get())
        for i in range(10):
            print((str(i) + "0-" + str(i) + "9: ", data[10 * i:10 * i + 10]))
        print(("PC: ", "{:02d}".format(self.PC.get()), "   Calc: ", "{:03d}".format(self.calculator.get())))
        print(("Intray: ", self.intray.get()))
        print(("Outtray: ", self.outtray.get()))

    def reset_all(self):
        self.reset_program_counter()
        self.intray.set([])
        self.outtray.set([])
        self.calculator.set(0)

    def increment_program_counter(self):
        self.PC.set((self.PC.get() + 1) % 100)

    def get_program_counter(self):
        if (not self.batchProcessing) and self.minion.speed < 30:
            self.controller.view1.highlightgreen(self.controller.view1.PCTray)
        return self.PC.get()

    def set_program_counter(self, new_value):
        self.PC.set(new_value % 100)

    def reset_program_counter(self):
        self.PC.set(0)

    def get_mailbox(self, mailbox):
        if (not self.batchProcessing) and self.minion.speed < 30:
            self.controller.view1.highlightgreen(self.controller.view1.memorycells[mailbox])
        return self.mailboxes[mailbox].get()

    def set_mailbox(self, mailbox, value):
        self.mailboxes[mailbox].set(value % 1000)

    def read_intray(self):
        if len(self.intray.get()) > 0:
            return self.intray.pop(0)
        elif self.batchProcessing:
            return 0
        else:
            return 'error'

    def put_in_intray(self, value):
        try:
            value = int(value) % 1000
            self.intray.append(value)
        except ValueError:
            print("Input must be an integer 000 - 999")

    def put_in_outtray(self, value):
        # print('Output: '+str(value))
        self.outtray.append(value)

    def load_assembly(self, file, is_data=False):
        my_assembler = Assembler(file, is_data)
        success, result, num_mailboxes = my_assembler.compile()
        if success:
            for i in range(len(result)):
                self.mailboxes[i].set(result[i])
        else:
            if not app.buttonsIsolatedforBatch:
                tk.messagebox.showerror("Error", "Your assembly code did not compile. Try loading it in the assembly editor and checking for errors.")
        return success, result, num_mailboxes

    def run(self, cycle, max_cycles=100000):
        # print('Running...')
        start_time = time.time()
        self.minion.fetch()
        self.minion.execute()
        if (not self.batchProcessing) and (cycle == 100):
            self.controller.runninglog('Minion has executed ' + str(cycle) + ' cycles', True)
            self.controller.root.update()
        if (not self.batchProcessing) and (cycle % 100 == 0) and cycle > 100:
            self.controller.runninglog('Minion has executed ' + str(cycle) + ' cycles')
            self.controller.root.update()
        # print(self.controller.askedToStop,cycle)
        if cycle > max_cycles:
            self.runresult = 'Max cycles reached', cycle
            self.controller.batchlog('Max cycles reached after ' + str(cycle) + ' cycles')
        elif self.controller.askedToStop:
            self.minion.halted.set(True)
            self.controller.batchlog('Minion stopped after ' + str(cycle) + ' cycles')
            self.controller.askedToStop = False
        elif self.minion.halted.get():
            self.runresult = 'LMC Halted', cycle
            self.controller.batchlog('Minion halted after ' + str(cycle) + ' cycles')
            self.controller.askedToStop = False
        else:
            wait_time = 1.0 / float(self.minion.speed) + start_time - time.time()
            if wait_time > 0 and float(self.minion.speed) < 30 and not self.batchProcessing:
                root.after(int(wait_time * 1000), lambda: self.run(cycle + 1, max_cycles))
            elif self.controller.askedToStop is False and not self.batchProcessing:
                root.after(1, lambda: self.run(cycle + 1, max_cycles))
            else:
                root.after(0, lambda: self.run(cycle + 1, max_cycles))

    def runforbatch(self, cycle, max_cycles=100000):
        # print('Running...')
        cycles = cycle
        while cycles < max_cycles:
            self.minion.fetch()
            self.minion.execute()
            cycles += 1
            if self.minion.halted.get():
                return 'LMC Halted', cycles
            elif self.controller.shutDownBatch:
                return 'stopped', cycles
        return 'Max cycles reached', cycles

    def batch_run(self, inputs, max_cycles):
        self.intray.set([])
        self.outtray.set([])
        for i in range(len(inputs)):
            self.put_in_intray(inputs[i])
        self.batchProcessing = True
        self.reset_program_counter()
        self.calculator.set(0)
        output = "    Output: "
        cycles = 0
        outputs = []

        result, cycles = self.runforbatch(0, max_cycles)
        for i in range(len(self.outtray.get())):
            output = output + str(self.outtray.get()[i]) + ', '
        if output[-2:] == ', ':
            output = output[:-2]
        self.batchProcessing = False
        if result == 'LMC Halted':
            output = output + "\n  Halted after " + str(cycles) + " Fetch/execute cycles."
            return [output, cycles, self.outtray.get(), True]
        else:
            output = output + "\n  Terminated after " + str(cycles) + " Fetch/execute cycles."
            return [output, cycles, self.outtray.get(), False]


class View(tk.Toplevel):
    def __init__(self, master):
        tk.Toplevel.__init__(self, master)

        self.protocol('WM_DELETE_WINDOW', self.master.destroy)
        self.title('Little Minion Computer')
        screen_height = self.winfo_screenheight()
        max_height = min(screen_height - 100, 770)
        self.geometry('1100x' + str(max_height) + '+50+0')
        self.f = tk.Frame(self)
        self.f.pack(fill=tk.BOTH, expand=tk.YES, padx=0, pady=0)
        self.f.columnconfigure(1, weight=1)
        self.f.rowconfigure(1, weight=1)
        self.logoimage = tk.PhotoImage(data=DU_logo)
        self.logo = tk.Label(self.f, image=self.logoimage)
        self.logo.photo = self.logoimage
        self.logo.grid(column=2, row=0)
        self.leftframe = tk.Frame(self.f)
        self.leftframe.grid(column=0, row=1, sticky=tk.W, padx=10, pady=10)
        textfr = tk.LabelFrame(self.f, text="Console")
        self.text = tk.Text(textfr, height=15, width=50, background='white')
        # put a scroll bar in the frame
        self.scroll = tk.Scrollbar(textfr, command=self.text.yview)
        self.text.configure(yscrollcommand=self.scroll.set)
        # pack everything
        self.text.pack(side=tk.LEFT)
        self.text.bind("<<Paste>>", self.scrolldown)
        self.scroll.pack(side=tk.RIGHT, fill=tk.Y)
        textfr.grid(column=0, row=2, rowspan=2, padx=10, pady=10)
        self.text.insert(tk.END, "Welcome to the Little Minion Computer\n\n")
        self.vcmd = (root.register(self.on_validate), '%d', '%i', '%P', '%s', '%S', '%v', '%V', '%W')
        self.vcmdPC = (root.register(self.on_validate_pc), '%d', '%i', '%P', '%s', '%S', '%v', '%V', '%W')
        self.entryframe = tk.LabelFrame(self.leftframe, text="Input")
        self.entryframe.pack(side=tk.TOP, padx=10, pady=12)
        self.entry = tk.Entry(self.entryframe, width=4)
        self.outFont = tkinter.font.Font(family="Lucida Grande", size=13)
        self.inTray = tk.Text(self.entryframe, height=8, width=4, background='white', font=self.outFont, state=tk.DISABLED)

        self.entry.pack(side=tk.BOTTOM)
        self.inTray.pack(side=tk.TOP)
        self.outframe = tk.LabelFrame(self.leftframe, text="Output")
        self.outframe.pack(side=tk.BOTTOM, padx=10, pady=12)
        self.outFont = tkinter.font.Font(family="Lucida Grande", size=13)
        self.outTray = tk.Text(self.outframe, height=6, width=4, background='white', font=self.outFont, state=tk.DISABLED)
        self.scrollOut = tk.Scrollbar(self.outframe, command=self.outTray.yview)
        self.outTray.configure(yscrollcommand=self.scrollOut.set)
        self.outTray.pack(side=tk.LEFT)
        self.scrollOut.pack(side=tk.RIGHT, fill=tk.Y)
        self.PCframe = tk.LabelFrame(self.f, text="Counter")
        self.PCframe.grid(column=1, row=2, sticky=tk.N, padx=10, pady=12)
        self.PCTray = tk.Entry(self.PCframe, width=2, validate="key", validatecommand=self.vcmdPC)

        self.ResetButton = tk.Button(self.PCframe, text="Reset")
        self.PCTray.pack(side=tk.LEFT, padx=5, pady=5)
        self.ResetButton.pack(side=tk.LEFT, padx=5, pady=5)
        self.calcframe = tk.LabelFrame(self.f, text="Calculator")
        self.calcframe.grid(column=0, columnspan=2, row=0, padx=10, pady=12)
        self.calc = tk.Label(self.calcframe, width=3)
        self.calc.pack(side=tk.LEFT, padx=10, pady=12)
        self.negFlag = tk.Label(self.calcframe, width=3, foreground='red')
        self.negFlag.pack(side=tk.LEFT, padx=0, pady=12)
        self.botFrame = tk.Frame(self.f)
        self.botFrame.grid(column=2, row=3, )
        # self.onestep = tk.Button(self.botFrame, text="One Step", width=13, command=self.pass_func)
        # self.onestep.grid(padx=10, pady=1)
        self.FEbutton = tk.Button(self.botFrame, text="Fetch-execute", width=13)
        self.FEbutton.grid(padx=10, pady=1)
        self.Runbutton = tk.Button(self.botFrame, text="Run", width=13, command=self.pass_func)
        self.Runbutton.grid(padx=10, pady=1)
        self.CheckVar = tk.IntVar()
        self.animation_check = tk.Checkbutton(self.botFrame, indicatoron=tk.FALSE, text="Animation", variable=self.CheckVar, width=12, height=1)
        self.animation_check.select()
        # self.animation_check.grid(column=1, row=0, padx=10, pady=1)
        self.SpeedSlider = tk.Scale(self.botFrame, from_=1, to=5, orient=tk.HORIZONTAL)
        self.SpeedSlider.set(1)
        self.SpeedSlider.grid(column=1, row=2, columnspan=2, padx=1, pady=1, sticky=tk.W)
        self.SpeedLabel = tk.Label(self.botFrame, text="Speed:", justify=tk.RIGHT)
        self.SpeedLabel.grid(column=0, row=2, columnspan=1, padx=1, pady=1, sticky=tk.SE)
        self.exit = tk.Button(self.botFrame, text="Exit", width=9, command=root.destroy)
        self.exit.grid(column=1, row=1, padx=10, pady=1)
        # self.save = Button(self.botFrame, text="Save", command=self.onSave)
        # self.save.grid(column=2,row=2,padx=10,pady=10)
        self.ResetAllButton = tk.Button(self.botFrame, text="Reset All", width=9)
        self.ResetAllButton.grid(column=1, row=0, padx=10, pady=1)
        ################################

        self.memory = tk.LabelFrame(self.f, text='Mailboxes')
        self.memory.grid(column=2, row=1, rowspan=2, sticky=tk.E, padx=10, pady=10)
        self.memoryframes = []
        self.memorycells = []
        self.memFont = tkinter.font.Font(family="Lucida Grande", size=10)
        self.mem12Font = tkinter.font.Font(family="Lucida Grande", size=12)
        if False:  # (is_windows):
            self.memFont = tk.font.Font(family="Lucida Grande", size=8)
            self.mem12Font = tk.font.Font(family="Lucida Grande", size=10)
        for i in range(100):
            self.memoryframes.append(tk.LabelFrame(self.memory, text='{:02d}'.format(i), padx=0, pady=0, font=self.memFont))
            self.memoryframes[i].grid(column=i % 10, row=i // 10)
            self.memorycells.append(tk.Entry(self.memoryframes[i], name='mem' + str(i), width=3, font=self.mem12Font, validate="key", validatecommand=self.vcmd))
            # self.memorycells[i].bind("<FocusOut>", self.memFocusOut)
            self.memorycells[i].pack(side=tk.BOTTOM, padx=0, pady=0)

        # Litte Minion
        self.LMframe = tk.Frame(self.f, bd=1, padx=2, pady=2)

        # print('Current dir', os.getcwd())
        # print('Current dir', os.path.dirname(sys.executable))
        try:
            if 'Images' in (os.listdir(os.getcwd())):
                imagepath = os.path.join(os.getcwd(), 'Images')
            elif 'Images' in (os.listdir(os.path.dirname(sys.executable))):
                imagepath = os.path.join(os.path.dirname(sys.executable), 'Images')
            else:
                imagepath = os.path.join(os.path.dirname(sys.executable), '..', '..', '..', 'Images')
            files = os.listdir(imagepath)
            # print(files)
            myfile = os.path.join(imagepath, random.choice(files))
            print(myfile)
            self.photo = tk.PhotoImage(file=myfile)

            zoomfactor = 12000 // self.photo.height()
            self.photo = self.photo.zoom(zoomfactor)  # with 250, I ended up running out of memory
            self.photo = self.photo.subsample(100)
            self.small_font = tkinter.font.Font(family="Lucida Grande", size=7)
            self.LM2frame = tk.Label(self.LMframe, height='120', image=self.photo)
            self.marframe = tk.LabelFrame(self.LM2frame, height=8, font=self.small_font, bd=0, text="MAR")
            self.mdrframe = tk.LabelFrame(self.LM2frame, font=self.small_font, bd=0, text="MDR")
            self.marLabel = tk.Label(self.marframe, font=self.small_font, bd=0, width=2)
            self.mdrLabel = tk.Label(self.mdrframe, font=self.small_font, bd=0, width=3)
            self.instructionLabel = tk.Label(self.LM2frame, font=self.small_font, bd=0, width=4)
            self.LM2frame.pack()
            self.LM2frame.grid_propagate(0)
            self.instructionLabel.place(x=40, y=55)
            self.marframe.place(x=30, y=70)
            self.mdrframe.place(x=50, y=70)
        ####
        except (IndexError, tk.TclError, IOError, OSError):
            print("error")
            self.LM2frame = tk.LabelFrame(self.LMframe, bd=2, padx=2, pady=2, text="Little Minion")
            self.marframe = tk.LabelFrame(self.LM2frame, text="MAR")
            self.mdrframe = tk.LabelFrame(self.LM2frame, text="MDR")
            self.marLabel = tk.Label(self.marframe, width=2)
            self.mdrLabel = tk.Label(self.mdrframe, width=3)
            self.instructionLabel = tk.Label(self.LM2frame, width=5)
            self.LM2frame.pack()
            self.instructionLabel.grid(columnspan=2)
            self.marframe.grid()
            self.mdrframe.grid(column=1, row=1)
        self.marLabel.pack()
        self.mdrLabel.pack()
        self.LMframe.place(x=150, y=150)

    def disable_fetch_execute_buttons(self):
        self.FEbutton.config(state="disabled")

    def enable_fetch_execute_buttons(self):
        self.FEbutton.config(state="normal")

    def scrolldown(self, event):
        root.update_idletasks()
        self.text.yview(tk.END)
        root.update_idletasks()

    def on_validate(self, d, i, P, s, S, v, V, W):
        return (P == '' or (is_number(P) and int(P) < 1000))

    def on_validate_pc(self, d, i, P, s, S, v, V, W):
        return (P == '' or (is_number(P) and int(P) < 100))

    def set_lm_position(self, position):
        self.LMframe.place(x=position[0], y=position[1])

    def set_mailboxes(self, value):
        for i in range(100):
            self.set_mailbox_ei(i, value[i])

    def set_mailbox_ei(self, index, value, highlight=True):
        self.memorycells[index].delete(0, 'end')
        self.memorycells[index].insert('end', '{:03d}'.format(value % 1000))
        if highlight:
            self.highlightred(self.memorycells[index])

    def set_calculator(self, value):
        self.calc['text'] = '{:03d}'.format(value % 1000)
        self.highlightred(self.calc)

    def set_mar(self, value):
        self.marLabel['text'] = '{:02d}'.format(value % 100)
        self.highlightred(self.marLabel)

    def set_mdr(self, value):
        self.mdrLabel['text'] = '{:03d}'.format(value % 1000)
        self.highlightred(self.mdrLabel)

    def set_instruction(self, value):
        self.instructionLabel['text'] = value
        self.highlightred(self.instructionLabel)

    def set_negflag(self, value):
        if value:
            self.negFlag['text'] = 'NEG'
        else:
            self.negFlag['text'] = '   '

    def set_pc(self, value):
        self.PCTray.delete(0, 'end')
        self.PCTray.insert('end', '{:02d}'.format(value % 100))
        self.highlightred(self.PCTray)

    def set_intray(self, value):
        self.inTray.config(state=tk.NORMAL)
        self.inTray.delete(1.0, tk.END)

        for i in range(6):
            try:
                if i < len(value):
                    self.inTray.insert(tk.END, '{}\n'.format(str(value[i]).zfill(3)))
                else:
                    self.inTray.insert(tk.END, '---\n')
                self.inTray.yview(tk.END)
            except ValueError:
                pass
        if len(value) > 6:
            self.inTray.insert(tk.END, ' + \n')
        self.inTray.config(state=tk.DISABLED)
        self.highlightred(self.inTray)

    def set_outtray(self, value):
        if len(value) == 0:
            self.outTray.config(state=tk.NORMAL)
            self.outTray.delete(1.0, tk.END)
            self.outTray.config(state=tk.DISABLED)
        else:
            try:
                self.outTray.config(state=tk.NORMAL)
                self.outTray.insert(tk.END, '{}\n'.format(str(value[len(value) - 1]).zfill(3)))
                self.outTray.yview(tk.END)
                self.outTray.config(state=tk.DISABLED)
            except ValueError:
                pass
        self.highlightred(self.outTray)

    def highlightred(self, item):
        item.configure(foreground='red')
        self.master.after(1500, self.resetcolour, item)

    def highlightgreen(self, item):
        item.configure(foreground='green')
        self.master.after(1000, self.resetcolour, item)

    def resetcolour(self, item):
        item.configure(foreground='black')

    def pass_func(self):
        pass


def select_file(type="LMC assembly"):
    root.update()
    # os.system('''/usr/bin/osascript -e 'tell app "Finder" to set frontmost of process "Python" to true' ''')
    myfile = filedialog.askopenfilename(defaultextension='.txt', filetypes=[(type, "*.txt"), ("All files", "*.*")], title='Choose a file to open')
    root.update()
    # root.destroy()
    return myfile


def batch_process():
    app.isolate_buttons_for_batch('start')
    answer = tk.messagebox.askokcancel("Batch process", ("Batch processing will run a set of tests on all the LMC assembly "
                                                         "or state files in a given folder.\n\n"
                                                         "The tests should be specified in a plaintext file in the same folder as the LMC files. "
                                                         "Each line of the test file should be in the format:\n   "
                                                         "   Comment;Inputs;Outputs;Max_cycles \n"
                                                         "where Inputs and Outputs are comma separated lists of integers.\n\n"
                                                         "Each source file in the same folder as the test file will be compiled "
                                                         "and run against each test in turn: i.e. run and supplied with the given inputs. "
                                                         "Between each test only the program counter is reset to zero, the source is not recompiled.\n\n"
                                                         "A feedback file for each source file and a summary of results (outputs.csv) is generated in the same folder.\n\n"
                                                         "Select the test file in the following dialog."))
    testfile = ''
    if answer:
        testfile = select_file("LMC batch test file")
    if testfile is not None and testfile != '':
        dir_path = os.path.dirname(testfile)
        tests = [x.strip('\n').split(';') for x in open(testfile, 'r').readlines()]
        max_inputs = 0
        max_outputs = 0
        for test in tests:
            if test[0][0] != '#':
                test[1] = (test[1].split(','))
                test[2] = (test[2].split(','))
                if len(test[1]) > max_inputs:
                    max_inputs = len(test[1])
                if len(test[2]) > max_outputs:
                    max_outputs = len(test[2])
        for test in tests:
            if test[0][0] != '#':
                while len(test[1]) < max_inputs:
                    test[1].append('')
                while len(test[2]) < max_outputs:
                    test[2].append('')
        outputfile_header = "Test#,File,Comment,"
        for i in range(max_inputs):
            outputfile_header = outputfile_header + 'Input_' + str(i + 1) + ','
        for i in range(max_outputs):
            outputfile_header = outputfile_header + 'Expected_output_' + str(i + 1) + ','
        outputfile_header = outputfile_header + "Max_cycles,Mailboxes_used,Cycles_used,Halted(1)_or_Terminated(0),Outputs\n"
        outputfile = open(os.path.join(dir_path, 'output.csv'), 'w')
        outputfile.write(outputfile_header)
        outputfile.close()
        program_files = os.listdir(dir_path)
        program_files.sort()
        for batchfile in program_files:

            if (batchfile[:8] != "Feedback") and (batchfile[0] != ".") and (batchfile != "output.csv") and (batchfile != testfile[-len(batchfile):]) and not app.shutDownBatch:
                print((''.join(('Processing file: ', batchfile))))
                app.batchlog((''.join(('Processing file: ', batchfile))))
                myfile = open(os.path.join(dir_path, batchfile), 'r')
                if batchfile.endswith(".lmc"):
                    feedbackfile = open(os.path.join(dir_path, 'Feedback_' + batchfile[:-4] + '.txt'), 'w')
                else:
                    feedbackfile = open(os.path.join(dir_path, 'Feedback_' + batchfile), 'w')
                feedbackfile.write(''.join(("Feedback for LMC file: ", batchfile, "\n\n\n")))

                if myfile is not None:
                    do_tests = False
                    num_mailboxes = 0
                    if batchfile.endswith(".lmc"):
                        data = myfile.readline()
                        data = data.strip('\r')
                        # print data
                        if data == '###LMC state file###\n':
                            data = myfile.read().split('%')
                            try:
                                app.model.set_program_counter(int(data[0]))
                                app.model.calculator.set(int(data[1]) % 1000)
                                temp = data[2].split(',')
                                for i in range(100):
                                    app.model.set_mailbox(i, int(temp[i]))
                                    if int(temp[i]) > 0:
                                        num_mailboxes = i + 1
                                temp = data[3].split(',')
                                for temp_item in temp:
                                    app.model.put_in_intray(int(temp_item))
                            except ValueError:
                                pass
                            feedbackfile.write(''.join(("Attempting to load: load successful. ", str(num_mailboxes), " mailboxes used.\n\n\n")))
                            do_tests = True
                        else:
                            feedbackfile.write("Attempting to load: load failed, bad file\n\n\n")
                            app.batchlog("   Attempting to load: load failed, bad file\n")
                        myfile.close()
                    else:
                        compile_success, result, num_mailboxes = app.model.load_assembly(os.path.join(dir_path, batchfile))
                        # app.model.dump_state()
                        # print ('num_mailboxes',num_mailboxes)
                        feedbackfile.write("Attempting to compile: ")
                        if compile_success:
                            do_tests = True
                            feedbackfile.write(''.join(('Compile successful. ', str(num_mailboxes), ' mailboxes used', '\n\n\n')))
                            app.batchlog(''.join(('   Compile successful. ', str(num_mailboxes), ' mailboxes used')))
                        else:
                            feedbackfile.write(''.join(('Compile failed; tests cannot be run.', '\n\n\n')))
                            app.batchlog(''.join(('   Compile failed; tests cannot be run.', '\n')))
                    if do_tests:
                        test_num = 1
                        for test in tests:
                            if (test[0][0] != '#') and (len(test) > 3) and not app.shutDownBatch:
                                # print(('    Test ' + str(test_num)))
                                feedbackfile.write(''.join(("Attempting to run test ", str(test_num), ": ", str(test[0]), "\n")))
                                app.batchlog(''.join(("   Attempting to run test ", str(test_num), ": ", str(test[0]))))
                                feedbackfile.write(''.join(("    Inputs: ", str(test[1]).replace("[", "").replace("]", "").replace("'", ""), "\n")))
                                feedbackfile.write(''.join(("  Expected: ", str(test[2]).replace("[", "").replace("]", "").replace("'", ""), "\n")))
                                run_result = app.model.batch_run(test[1], int(test[3]))
                                feedbackfile.write(run_result[0] + '\n\n')
                                outputtext = ''.join((str(test_num), ',', batchfile.replace(",", ""), ",", test[0], ',', str(test[1]).replace("[", "").replace("]", "").replace("'", ""), ',',
                                                      str(test[2]).replace("[", "").replace("]", "").replace("'", ""), ',', test[3], ',', str(num_mailboxes), ",", str(run_result[1]), ",", str(int(run_result[3])), ",",
                                                      str(run_result[2]).replace("[", "").replace("]", ""), "\n"))
                                with open(os.path.join(dir_path, 'output.csv'), "a") as outputfile:
                                    outputfile.write(outputtext)
                                test_num += 1
                    else:
                        outputtext = ''.join((str(0), ',', batchfile.replace(",", ""), ", COMPILE FAILED\n"))
                        with open(os.path.join(dir_path, 'output.csv'), "a") as outputfile:
                            outputfile.write(outputtext)
                feedbackfile.close()
        if not app.shutDownBatch:
            print("Batch processing completed")
            app.batchlog("Batch processing completed")
        else:
            print("Batch processing stopped")
            app.batchlog("Batch processing stopped")
    app.isolate_buttons_for_batch('end')


def on_open():
    root.update()
    open_file = filedialog.askopenfilename(defaultextension='.lmc', filetypes=[("LMC state file", "*.lmc"), ("All files", "*.*")], title='Choose a file to open')
    root.update()
    try:
        myfile = open(open_file, "r")
        if myfile is not None:
            data = myfile.readline()
            data = data.replace('\r', '')
            # print data
            if data == '###LMC state file###\n':
                data = myfile.read().split('%')
                app.model.set_program_counter(int(data[0]))
                app.model.calculator.set(int(data[1]))
                temp = data[2].split(',')
                for i in range(100):
                    app.model.set_mailbox(i, int(temp[i]))
                temp = data[3].split(',')
                for val in temp:
                    try:
                        app.model.put_in_intray(int(val))
                    except ValueError:
                        pass
                if app.model.minion.speed == 30:
                    app.model.controller.refresh_all()  # if data[4] == 'AnimationOn':  #     app.animations_on = True  # if data[4] == 'AnimationOff':  #     app.animations_on = False
            else:
                print('Bad file')
            myfile.close()
    except FileNotFoundError:
        pass


def on_save():
    filename = filedialog.asksaveasfilename(parent=root, defaultextension=".lmc", filetypes=[("LMC files", "*.lmc")], title='Save file as')
    if filename is not None:
        if filename.count('.') == 0:
            filename = filename + '.lmc'
        myfile = open(filename, 'w')
        myfile.write('###LMC state file###\n')
        myfile.write(str(app.model.get_program_counter()) + '%')
        myfile.write(str(app.model.calculator.get()) + '%')
        for i in range(100):
            myfile.write(str(app.model.get_mailbox(i)) + ',')
        myfile.write('%')
        in_tray = app.model.intray.get()
        for i in range(len(in_tray)):
            myfile.write(str(in_tray[i]) + ',')
        myfile.write('%')
        if app.animations_on:
            myfile.write('AnimationOn')
        else:
            myfile.write('AnimationOff')
        myfile.close()


def on_open_assembly():
    root.update()
    myfile = filedialog.askopenfilename(parent=root, defaultextension='.txt', filetypes=[("LMC assembly", "*.txt"), ("All files", "*.*")], title='Choose a file to open')
    time.sleep(0.1)
    root.update()
    try:
        app.model.load_assembly(myfile)
        app.model.reset_program_counter()
        if app.model.minion.speed == 30:
            app.model.controller.refresh_all()
    except FileNotFoundError:
        pass


def on_open_editor():
    editor = AssemblerGUI(root)
    root.wait_window(editor.frm)


if __name__ == '__main__':
    root = tk.Tk()
    root.withdraw()
    app = Controller(root)
    # myLMC=LMC()

    # print(platform.system())
    is_windows = (platform.system().lower().find("window") > -1)
    is_linux = "linux" in platform.system().lower()
    is_mac = "darwin" in platform.system().lower()
    # print(is_windows)
    root.title('Little Minion Computer')
    menubar = tk.Menu(root)
    # create a pulldown menu, and add it to the menu bar
    apple = tk.Menu(menubar, name='apple', tearoff=0)
    # helpmenu = Menu(menubar, name='help', tearoff=0)
    menubar.add_cascade(menu=apple)
    # menubar.add_cascade(menu=help)
    filemenu = tk.Menu(menubar, tearoff=0)
    filemenu.add_command(label="Open .lmc", command=on_open)
    filemenu.add_command(label="Save .lmc", command=on_save)
    filemenu.add_command(label="Open assembly file", command=on_open_assembly)
    filemenu.add_command(label="Assembly Editor", command=on_open_editor)
    filemenu.add_command(label="Batch Process", command=batch_process)
    # filemenu.add_separator()
    # filemenu.add_command(label="Exit", command=root.quit)
    menubar.add_cascade(label="File", menu=filemenu)
    helpmenu = tk.Menu(menubar, tearoff=0)
    helpmenu.add_command(label="About", command=about)
    helpmenu.add_command(label="Bug report", command=bug_report)
    helpmenu.add_command(label="Online Help", command=help_menu)
    menubar.add_cascade(label="Help", menu=helpmenu)
    # root.tk.call('tk', 'menu .menubar.apple')
    # root.tk.call('tk', '.menubar add cascade -menu .mbar.apple')
    # apple = Menu(menubar, tearoff=0)
    apple.add_command(label="About this software ...", command=about)
    # menubar.add_cascade(label="Python", menu=apple)
    # display the menu
    root.config(menu=menubar)


    def _quit(event):
        root.destroy()


    root.bind('<Command-Q>', _quit)
    root.bind('<Command-q>', _quit)


    def hide_tk_console(root):
        try:
            root.tk.call('console', 'hide')
        except tk.TclError:
            # Some versions of the Tk framework don't have a console object
            pass


    hide_tk_console(root)
    root.lift()
    root.call('wm', 'attributes', '.', '-topmost', True)
    root.after_idle(root.call, 'wm', 'attributes', '.', '-topmost', False)
    os.system('''/usr/bin/osascript -e 'tell app "Finder" to set frontmost of process "Python" to true' ''')
    root.mainloop()
